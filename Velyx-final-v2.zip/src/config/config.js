import dotenv from "dotenv";
dotenv.config();

const config = {
    token: "" || process.env.TOKEN,
    clientId: "" || process.env.CLIENT_ID,
    prefix: '-',
    color: 0x5865F2,        // Velyx brand color (blurple — change to your own)
    botName: 'Velyx',
    version: '2.0.0',
    owners: [
        '1200413181768630322',   // ← add your ID here
        '1173632925657477131',        // ← add more if needed
    ],
    links: {
        supportServer: "https://discord.gg/ZfRZDXPrBc",
        invite: "",          // Leave blank — auto-generated from client ID at runtime
    },
    webhooks: {
        error: process.env.ERROR_WEBHOOK || "https://discord.com/api/webhooks/1449668049681518694/WPPKFx5C16-2cIwHw5XmTpSeAuunK6AfFX_4IWo0EZX5soeOubiO2j4kzwIELlsfowyB",
    },
    spotify: {
        id: process.env.SPOTIFY_ID || 'decf2ebf5d0b4b84af95cb0c134aca6d',
        secret: process.env.SPOTIFY_SECRET || '69c12a3dc84449d8a845494a3f00b66e'
    }
};

export default config;
