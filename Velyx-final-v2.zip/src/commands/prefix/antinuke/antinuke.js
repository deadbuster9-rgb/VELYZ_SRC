import { ActionRowBuilder, ButtonBuilder, ButtonStyle, Embed, EmbedBuilder, MessageFlags, PermissionFlagsBits, StringSelectMenuBuilder } from 'discord.js'
import emojis from '../../../config/emojis.js'
import { isBotOwner } from '../../../utils/isBotOwner.js'
import { paginate } from '../../../utils/pagination.js'
export const data = {
    name: 'antinuke',
    description: 'manages the antinuke system of the bot.',
    aliases: ['an'],
    subcCommandCount: 14,
    /**
     * @param {import('discord.js').Message} message 
     * @param {String[]} args 
     * @param {import('../../../base/Velyx.js').Velyx} client 
     */
    async execute(message, args, client) {
        const guild = message.guild
        const antinukeDB = client.antinukeDB
        const antinukeData = await antinukeDB.get(`antinukeData_${guild.id}`)
        if (!isBotOwner(message.author.id) && message.author.id !== guild.ownerId && !antinukeData?.extraOwners?.includes(message.author.id)) {
            return message.reply({
                embeds: [
                    new EmbedBuilder()
                        .setDescription(`${emojis.warn} **Only server owner & extra owners can use this command.**`)
                        .setColor(client.color)
                ]
            })
        }

        const subcommand = args[0]
        const action = args[1]

        switch (subcommand) {
            case 'enable': {
                if (antinukeData?.enabled) {
                    return message.reply({
                        embeds: [
                            new EmbedBuilder()
                                .setAuthor({ name: 'Velyx Antinuke', iconURL: client.user.avatarURL({ size: 1024 }) })
                                .setDescription(`${emojis.warn} **Antinuke system is already enabled in this server.**\n\n`
                                    + `__**Current Status**__\n`
                                    + `${emojis.arrow} **State:** ${antinukeData?.enabled ? `\`Enabled\` ${emojis.tick}` : `\`Disabled\` ${emojis.cross}`}\n`
                                    + `${emojis.arrow} **Use \`antinuke disable\` to turn off protection**\n\n`
                                    + `${emojis.info} **Note:** For full functionality, ensure "Velyx Protect" role is at the top`)
                                .setThumbnail(guild.iconURL({ size: 1024 }))
                                .setColor(client.color)
                        ]
                    })
                }

                const setupEmbed = new EmbedBuilder()
                    .setAuthor({ name: 'Velyx Antinuke Setup', iconURL: client.user.avatarURL({ size: 1024 }) })
                    .setDescription(`${emojis.antinuke} **Initializing protection setup...**`)
                    .setColor(client.color)
                    .setFooter({ text: `Executed by ${message.author.username}`, iconURL: message.author.avatarURL({ size: 1024 }) })
                    .setThumbnail(guild.iconURL({ size: 1024 }))

                const msg = await message.reply({ embeds: [setupEmbed] })
                await new Promise(resolve => setTimeout(resolve, 600))

                setupEmbed.setDescription(`${emojis.antinuke} **Initializing protection setup...**\n`
                    + `> ${emojis.loading} Checking required permissions`
                )
                await msg.edit({ embeds: [setupEmbed] })
                await new Promise(resolve => setTimeout(resolve, 600))

                if (!guild.members.me.permissions.has(PermissionFlagsBits.Administrator)) {
                    setupEmbed.setDescription(`${emojis.cross} **Setup failed**\n`
                        + `> Missing required permission: \`Administrator\`\n\n`
                        + `${emojis.info} The bot requires administrator permissions to properly protect your server.`
                    )
                    return msg.edit({ embeds: [setupEmbed] })
                }

                setupEmbed.setDescription(`${emojis.antinuke} **Initializing protection setup...**\n`
                    + `> ${emojis.tick} Permission check passed\n`
                    + `> ${emojis.loading} Creating protection role`
                )
                await msg.edit({ embeds: [setupEmbed] })
                await new Promise(resolve => setTimeout(resolve, 600))

                const protectRole = await guild.roles.create({
                    name: 'Velyx Protect',
                    color: '#ef9a12',
                    reason: 'Server protection system',
                    permissions: []
                })

                setupEmbed.setDescription(`${emojis.antinuke} **Initializing protection setup...**\n`
                    + `> ${emojis.tick} Permission check passed\n`
                    + `> ${emojis.tick} Created protection role (<@&${protectRole.id}>)\n`
                    + `> ${emojis.loading} Configuring system settings`
                )
                await msg.edit({ embeds: [setupEmbed] })
                await new Promise(resolve => setTimeout(resolve, 600))

                const newConfig = {
                    enabled: true,
                    extraOwners: [],
                    whitelisted: {},
                    whitelistedRoles: {},
                    protectRole: protectRole.id,
                    logsChannel: null,
                    punishment: 'ban'
                }
                await antinukeDB.set(`antinukeData_${guild.id}`, newConfig)

                setupEmbed.setDescription(`${emojis.antinuke} **Initializing protection setup...**\n`
                    + `> ${emojis.tick} Permission check passed\n`
                    + `> ${emojis.tick} Created protection role (<@&${protectRole.id}>)\n`
                    + `> ${emojis.tick} System configuration saved\n`
                    + `> ${emojis.loading} Positioning protection role`
                )
                await msg.edit({ embeds: [setupEmbed] })
                await new Promise(resolve => setTimeout(resolve, 600))

                try {
                    const highestRole = guild.roles.cache
                        .filter(r => r.id !== guild.roles.everyone.id)
                        .sort((a, b) => b.position - a.position)
                        .first()

                    if (highestRole && highestRole.position > protectRole.position) {
                        await protectRole.setPosition(highestRole.position - 1)
                    }
                } catch (roleError) {
                }

                setupEmbed.setDescription(
                    `${emojis.tick} **Protection Setup Complete!**\n\n` +
                    `__**${emojis.antinuke} Protection Details**__\n` +
                    `> ${emojis.arrow} **Role:** <@&${protectRole.id}>\n` +
                    `> ${emojis.arrow} **Default Action:** \`${newConfig.punishment.toUpperCase()}\`\n\n` +
                    `__**${emojis.gear} Active Protection Events**__\n` +
                    `> ${emojis.enabled} **Anti Bot**\n` +
                    `> ${emojis.enabled} **Anti Ban**\n` +
                    `> ${emojis.enabled} **Anti Kick**\n` +
                    `> ${emojis.enabled} **Anti Channel Create**\n` +
                    `> ${emojis.enabled} **Anti Channel Delete**\n` +
                    `> ${emojis.enabled} **Anti Channel Update**\n` +
                    `> ${emojis.enabled} **Anti Sticker Create**\n` +
                    `> ${emojis.enabled} **Anti Sticker Delete**\n` +
                    `> ${emojis.enabled} **Anti Sticker Update**\n` +
                    `> ${emojis.enabled} **Anti Guild Update**\n` +
                    `> ${emojis.enabled} **Anti Role Create**\n` +
                    `> ${emojis.enabled} **Anti Role Delete**\n` +
                    `> ${emojis.enabled} **Anti Role Update**\n` +
                    `> ${emojis.enabled} **Anti Unban**\n` +
                    `> ${emojis.enabled} **Anti Webhook Update**\n` +
                    `> ${emojis.enabled} **Anti Member Update**\n` +
                    `> ${emojis.enabled} **Anti Emoji Update**\n` +
                    `> ${emojis.enabled} **Anti Emoji Create**\n` +
                    `> ${emojis.enabled} **Anti Emoji Delete**\n` +
                    `> ${emojis.enabled} **Anti Prune**\n` +
                    `> ${emojis.enabled} **Anti Ping**\n` +
                    `> ${emojis.enabled} **Auto Recovery**\n\n` +
                    `-# **Note:- Move my "Velyx Protect" role to the top of all roles for the best performance**`
                )
                setupEmbed.setThumbnail(guild.iconURL({ size: 1024 }))
                setupEmbed.setColor(client.color)
                await msg.edit({ embeds: [setupEmbed] })
                await new Promise(resolve => setTimeout(resolve, 3000))
                break;
            }

            case 'disable': {
                if (!antinukeData?.enabled) {
                    return message.reply({
                        embeds: [
                            new EmbedBuilder()
                                .setAuthor({ name: 'Velyx Antinuke', iconURL: client.user.avatarURL({ size: 1024 }) })
                                .setDescription(`${emojis.warn} **Antinuke system is already disabled in this server.**\n\n`
                                    + `__**Current Status**__\n`
                                    + `${emojis.arrow} **State:** ${antinukeData?.enabled ? `\`Enabled\` ${emojis.tick}` : `\`Disabled\` ${emojis.cross}`}\n`
                                    + `${emojis.arrow} **Use \`antinuke enable\` to activate protection**\n\n`
                                    + `${emojis.info} **Note:** All protections will remain inactive until enabled`)
                                .setThumbnail(guild.iconURL({ size: 1024 }))
                                .setColor(client.color)
                        ]
                    })
                }

                const disableEmbed = new EmbedBuilder()
                    .setAuthor({ name: 'Velyx Antinuke Setup', iconURL: client.user.avatarURL({ size: 1024 }) })
                    .setDescription(`${emojis.antinuke} **Initializing full protection shutdown...**`)
                    .setColor(client.color)
                    .setFooter({ text: `Executed by ${message.author.username}`, iconURL: message.author.avatarURL({ size: 1024 }) })
                    .setThumbnail(guild.iconURL({ size: 1024 }))

                const msg = await message.reply({ embeds: [disableEmbed] })
                await new Promise(resolve => setTimeout(resolve, 600))

                disableEmbed.setDescription(`${emojis.antinuke} **Initializing full protection shutdown...**\n`
                    + `> ${emojis.loading} Checking required permissions`
                )
                await msg.edit({ embeds: [disableEmbed] })
                await new Promise(resolve => setTimeout(resolve, 600))

                if (!guild.members.me.permissions.has(PermissionFlagsBits.Administrator)) {
                    disableEmbed.setDescription(`${emojis.cross} **Disable failed**\n`
                        + `> Missing required permission: \`Administrator\`\n\n`
                        + `${emojis.info} The bot requires administrator permissions to remove protection systems.`
                    )
                    return msg.edit({ embeds: [disableEmbed] })
                }

                disableEmbed.setDescription(`${emojis.antinuke} **Initializing full protection shutdown...**\n`
                    + `> ${emojis.tick} Permission check passed\n`
                    + `> ${emojis.loading} Disabling all protection modules`
                )
                await msg.edit({ embeds: [disableEmbed] })
                await new Promise(resolve => setTimeout(resolve, 600))

                let roleDeleted = false
                if (antinukeData.protectRole) {
                    try {
                        const role = await guild.roles.fetch(antinukeData.protectRole)
                        if (role) {
                            await role.delete('Antinuke system disabled')
                            roleDeleted = true
                        }
                    } catch (error) {
                    }
                }

                disableEmbed.setDescription(`${emojis.antinuke} **Initializing full protection shutdown...**\n`
                    + `> ${emojis.tick} Permission check passed\n`
                    + `> ${emojis.tick} Protection modules disabled\n`
                    + `> ${roleDeleted ? `${emojis.tick}` : `${emojis.cross}`} Protection role ${roleDeleted ? 'deleted' : 'not found'}\n`
                    + `> ${emojis.loading} Clearing all configuration data`
                )
                await msg.edit({ embeds: [disableEmbed] })
                await new Promise(resolve => setTimeout(resolve, 600))

                await antinukeDB.delete(`antinukeData_${guild.id}`)

                disableEmbed.setDescription(
                    `${emojis.tick} **Complete System Shutdown!**\n\n`
                    + `__**${emojis.warn} All Protection Removed**__\n`
                    + `> ${emojis.arrow} **Status:** \`Disable\` ${emojis.cross}\n`
                    + `> ${emojis.arrow} **Role:** ${roleDeleted ? '`Deleted`' : '`Not found`'}\n\n`
                    + `-# Use \`antinuke enable\` to set up a new protection system.`
                )
                disableEmbed.setColor(client.color)
                await msg.edit({ embeds: [disableEmbed] })
                await new Promise(resolve => setTimeout(resolve, 3000))
                break
            }
            case 'owner':
            case 'eo':
            case 'extraowner': {
                const member = message.mentions.members.first() || message.guild.members.fetch(args[2])
                const extraOwners = antinukeData?.extraOwners || []

                if (!message.author.id !== guild.ownerId && !isBotOwner(message.author.id)) {
                    return message.reply({
                        embeds: [
                            new EmbedBuilder()
                                .setDescription(`${emojis.warn} **Only server owner can use this command**`)
                                .setColor(client.color)
                        ]
                    })
                }

                if (!action) {
                    return message.reply({
                        embeds: [
                            new EmbedBuilder()
                                .setAuthor({ name: 'Velyx Antinuke', iconURL: client.user.avatarURL({ size: 1024 }) })
                                .setDescription(
                                    `**Extra Owner Management**\n\n` +
                                    `- \`antinuke extraowner add <member>\`\n└  Adds a extraowner\n\n` +
                                    `- \`antinuke extraowner remove <member>\`\n└  Removes a extraowner\n\n` +
                                    `- \`antinuke extraowner show\`\n└  Shows the extraowners list\n\n` +
                                    `- \`antinuke extraowner reset\`\n└  Resets the extraowner list\n\n`
                                )
                                .setFooter({ text: `Requested by ${message.author.username}`, iconURL: message.author.avatarURL({ size: 1024 }) })
                                .setColor(client.color)
                        ]
                    })
                }

                switch (action) {
                    case 'add': {
                        if (!antinukeData?.enabled) {
                            return message.reply({
                                embeds: [
                                    new EmbedBuilder()
                                        .setDescription(`${emojis.warn} **Antinuke is not enabled in this server**`)
                                        .setColor(client.color)
                                ]
                            })
                        }
                        if (!args[2]) {
                            return message.reply({
                                embeds: [
                                    new EmbedBuilder()

                                        .setDescription(`${emojis.warn} **Please mention a valid Member or provide a valid Member ID.**`)
                                        .setColor(client.color)
                                ]
                            })
                        }
                        if (!member) {
                            return message.reply({
                                embeds: [
                                    new EmbedBuilder()

                                        .setDescription(`${emojis.warn} **Please mention a valid Member or provide a valid Member ID.**`)
                                        .setColor(client.color)
                                ]
                            })
                        }

                        if (extraOwners.includes(member.user.id)) {
                            return message.channel.send({
                                embeds: [
                                    new EmbedBuilder()
                                        .setColor(client.color)
                                        .setDescription(`${emojis.warn} **This user is already an extra owner.**`)
                                ]
                            });
                        }

                        extraOwners?.push(member.user.id);

                        await antinukeDB.set(`antinukeData_${guild.id}.extraOwners`, extraOwners).then(() => {
                            return message.reply({
                                embeds: [
                                    new EmbedBuilder()

                                        .setColor(client.color)
                                        .setDescription(`${emojis.tick} ${member} **has been added to Extra Owners.**`)
                                ]
                            })
                        })

                        return
                    }
                    case 'show': {
                        if (!antinukeData?.enabled) {
                            return message.reply({
                                embeds: [
                                    new EmbedBuilder()
                                        .setDescription(`${emojis.warn} **Antinuke is not enabled in this server**`)
                                        .setColor(client.color)
                                ]
                            })
                        }
                        if (extraOwners.length === 0) {
                            return message.reply({
                                embeds: [
                                    new EmbedBuilder()

                                        .setColor(client.color)
                                        .setDescription(`${emojis.warn} **No Extra Owners have been set.**`)
                                ]
                            });
                        }

                        const itemsPerPage = 5;
                        let page = 0;
                        const totalPages = Math.ceil(extraOwners.length / itemsPerPage);

                        const generateEmbed = (pageNum) => {
                            const start = pageNum * itemsPerPage;
                            const end = start + itemsPerPage;
                            const pageItems = extraOwners.slice(start, end);

                            const embed = new EmbedBuilder()
                                .setTitle("Extra Owners List")
                                .setColor(client.color)
                                .setFooter({ text: `Page ${pageNum + 1} of ${totalPages}` })
                                .setThumbnail(message.guild.iconURL({ size: 1024 }));
                            let description = ``
                            pageItems.forEach((id) => {
                                const owner = client.users.cache.get(id);
                                description += `${owner} (\`${id}\`)\n`
                            });
                            embed.setDescription(description)
                            return embed;
                        };

                        await paginate(message, extraOwners, itemsPerPage, generateEmbed);

                        return;
                    }

                    case 'remove': {
                        if (!antinukeData?.enabled) {
                            return message.reply({
                                embeds: [
                                    new EmbedBuilder()
                                        .setDescription(`${emojis.warn} **Antinuke is not enabled in this server**`)
                                        .setColor(client.color)
                                ]
                            })
                        }
                        if (!args[2]) {
                            return message.reply({
                                embeds: [
                                    new EmbedBuilder()

                                        .setDescription(`${emojis.warn} **Please mention a valid Member or provide a valid Member ID.**`)
                                        .setColor(client.color)
                                ]
                            })
                        }
                        if (!member) {
                            return message.reply({
                                embeds: [
                                    new EmbedBuilder()
                                        .setDescription(`${emojis.warn} **Please mention a valid Member or provide a valid Member ID.**`)
                                        .setColor(client.color)
                                ]
                            })
                        }

                        if (!extraOwners.includes(member.user.id)) {
                            return message.reply({
                                embeds: [
                                    new EmbedBuilder()

                                        .setDescription(`${emojis.warn} ${member} **is not in the Extra Owners.**`)
                                        .setColor(client.color)
                                ]
                            })
                        }

                        const extraOwners2 = extraOwners.filter(id => id !== member.user.id);
                        await antinukeDB.set(`antinukeData_${guild.id}.extraOwners`, extraOwners2).then(() => {
                            return message.reply({
                                embeds: [
                                    new EmbedBuilder()

                                        .setDescription(`${emojis.tick} **Successfully remove ${member} from Extra Owners**`)
                                        .setColor(client.color)
                                ]
                            })
                        })

                        return;
                    }

                    case 'reset': {
                        if (!antinukeData?.enabled) {
                            return message.reply({
                                embeds: [
                                    new EmbedBuilder()
                                        .setDescription(`${emojis.warn} **Antinuke is not enabled in this server**`)
                                        .setColor(client.color)
                                ]
                            })
                        }
                        await antinukeDB.set(`antinukeData_${guild.id}.extraOwners`, [])
                        return message.reply({
                            embeds: [
                                new EmbedBuilder()

                                    .setDescription(`${emojis.warn} **Successfully reseted all extra owners for this guild.**`)
                                    .setColor(client.color)
                            ]
                        })
                    }

                    default: {
                        return message.reply({
                            embeds: [
                                new EmbedBuilder()
                                    .setAuthor({ name: 'Velyx Antinuke', iconURL: client.user.avatarURL({ size: 1024 }) })
                                    .setDescription(
                                        `**Extra Owner Management**\n\n` +
                                        `- \`antinuke extraowner add <member>\`\n└  Adds a extraowner\n\n` +
                                        `- \`antinuke extraowner remove <member>\`\n└  Removes a extraowner\n\n` +
                                        `- \`antinuke extraowner show\`\n└  Shows the extraowners list\n\n` +
                                        `- \`antinuke extraowner reset\`\n└  Resets the extraowner list\n\n`
                                    )
                                    .setColor(client.color)
                            ]
                        })
                    }
                }
            }
            case 'wl':
            case 'whitelist': {
                const member = message.mentions.members.first() || message.guild.members.fetch(args[2])


                if (!action) {
                    return message.reply({
                        embeds: [
                            new EmbedBuilder()
                                .setAuthor({ name: 'Velyx Antinuke', iconURL: client.user.avatarURL({ size: 1024 }) })
                                .setDescription(
                                    `**Whitelist Management**\n\n` +
                                    `- \`antinuke whitelist add <member>\`\n└  Adds a whitelist user\n\n` +
                                    `- \`antinuke whitelist remove <member>\`\n└  Removes a whitelist user\n\n` +
                                    `- \`antinuke whitelist show\`\n└  Shows the whitelist users list\n\n` +
                                    `- \`antinuke whitelist reset\`\n└  Resets the whitelist\n\n`
                                )
                                .setFooter({ text: `Requested by ${message.author.username}`, iconURL: message.author.avatarURL({ size: 1024 }) })
                                .setColor(client.color)
                        ]
                    })
                }

                const fields = [
                    { name: 'Anti Bot', key: 'antiBot' },
                    { name: 'Anti Ban', key: 'antiBan' },
                    { name: 'Anti Kick', key: 'antiKick' },
                    { name: 'Anti Channel Create', key: 'antiChannelCreate' },
                    { name: 'Anti Channel Delete', key: 'antiChannelDelete' },
                    { name: 'Anti Channel Update', key: 'antiChannelUpdate' },
                    { name: 'Anti Sticker Create', key: 'antiStickerCreate' },
                    { name: 'Anti Sticker Delete', key: 'antiStickerDelete' },
                    { name: 'Anti Sticker Update', key: 'antiStickerUpdate' },
                    { name: 'Anti Guild Update', key: 'antiGuildUpdate' },
                    { name: 'Anti Role Create', key: 'antiRoleCreate' },
                    { name: 'Anti Role Delete', key: 'antiRoleDelete' },
                    { name: 'Anti Role Update', key: 'antiRoleUpdate' },
                    { name: 'Anti Unban', key: 'antiUnban' },
                    { name: 'Anti Webhook Update', key: 'antiWebhookUpdate' },
                    { name: 'Anti Member Update', key: 'antiMemberUpdate' },
                    { name: 'Anti Emoji Update', key: 'antiEmojiUpdate' },
                    { name: 'Anti Emoji Create', key: 'antiEmojiCreate' },
                    { name: 'Anti Emoji Delete', key: 'antiEmojiDelete' },
                    { name: 'Anti Prune', key: 'antiPrune' },
                    { name: 'Anti Ping', key: 'antiPing' },
                ];

                switch (action) {
                    case 'add': {
                        if (!antinukeData?.enabled) {
                            return message.reply({
                                embeds: [
                                    new EmbedBuilder()
                                        .setDescription(`${emojis.warn} **Antinuke is not enabled in this server**`)
                                        .setColor(client.color)
                                ]
                            })
                        }
                        if (!args[2]) {
                            return message.reply({
                                embeds: [
                                    new EmbedBuilder()

                                        .setDescription(`${emojis.warn} **Please mention a valid Member or provide a valid Member ID.**`)
                                        .setColor(client.color)
                                ]
                            })
                        }
                        if (!member) {
                            return message.reply({
                                embeds: [
                                    new EmbedBuilder()

                                        .setDescription(`${emojis.warn} **Please mention a valid Member or provide a valid Member ID.**`)
                                        .setColor(client.color)
                                ]
                            })
                        }

                        let whitelist = antinukeData?.whitelisted || {}

                        if (whitelist[member.user.id]) {
                            return message.reply({
                                embeds: [
                                    new EmbedBuilder()
                                        .setColor(client.color)
                                        .setDescription(`${emojis.warn} **This user is already whitelisted.**`)
                                ]
                            });
                        }



                        const selectMenu = new StringSelectMenuBuilder()
                            .setCustomId(`whitelist_select_${member.user.id}`)
                            .setPlaceholder('Select events to whitelist')
                            .setMinValues(1)
                            .setMaxValues(fields.length)
                            .addOptions(fields.map(field => ({ label: field.name, value: field.key })));

                        const whitelistAllButton = new ButtonBuilder()
                            .setCustomId(`whitelist_all_${member.user.id}`)
                            .setLabel('Whitelist All Events')
                            .setEmoji(emojis.gear)
                            .setStyle(ButtonStyle.Secondary);

                        const actionRow = new ActionRowBuilder().addComponents(selectMenu);
                        const buttonRow = new ActionRowBuilder().addComponents(whitelistAllButton);


                        const embed = new EmbedBuilder()
                            .setColor(client.color)
                            .setAuthor({ name: 'Whitelist User for Antinuke Events', iconURL: member.user.avatarURL({ size: 1024 }) })
                            .setDescription(`Select the events to whitelist using the dropdown below or use the button to whitelist all.`)
                            .setFooter({ text: `Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL() });

                        const sentMessage = await message.reply({ embeds: [embed], components: [actionRow, buttonRow] });

                        const collector = sentMessage.createMessageComponentCollector({ time: 60000 });

                        collector.on('collect', async (i) => {
                            if (i.user.id !== message.author.id) {
                                return i.reply({ content: 'You cannot interact with this.', flags: MessageFlags.Ephemeral });
                            }

                            if (i.customId === `whitelist_select_${member.user.id}`) {
                                await i.reply({
                                    embeds: [
                                        new EmbedBuilder()
                                            .setDescription(`${emojis.loading} **Adding selected events to ${member}**`)
                                            .setColor(client.color)
                                    ],
                                    flags: MessageFlags.Ephemeral
                                });

                                await client.antinukeDB.set(`antinukeData_${guild.id}.whitelisted.${member.user.id}`, {
                                    events: i.values,
                                    executorId: message.author.id,
                                    timestamp: Date.now()
                                });

                                const selectedLabels = fields
                                    .filter(field => i.values.includes(field.key))
                                    .map(field => `${emojis.enabled} **${field.name}**`)
                                    .join("\n");

                                await i.editReply({
                                    embeds: [
                                        new EmbedBuilder()
                                            .setDescription(`${emojis.tick} **${member} has been whitelisted for selected events**`)
                                            .setColor(client.color)
                                    ]
                                });

                                await sentMessage.edit({
                                    embeds: [
                                        new EmbedBuilder()
                                            .setColor(client.color)
                                            .setAuthor({ name: member.user.username, iconURL: member.user.avatarURL({ size: 1024 }) })
                                            .setDescription(`${emojis.tick} **${member} has been whitelisted for selected events**\n\n${emojis.user} **Target:** ${member}\n${emojis.executor} **Executor: ${message.member}**\n\n__**Events**__\n${selectedLabels}`)
                                            .setFooter({ text: `Executed by ${message.author.username}`, iconURL: message.author.displayAvatarURL() })
                                    ],
                                    components: []
                                });

                                collector.stop();
                            }

                            else if (i.customId === `whitelist_all_${member.user.id}`) {
                                await i.reply({
                                    embeds: [
                                        new EmbedBuilder()
                                            .setDescription(`${emojis.loading} **Whitelisting ${member} for all events...**`)
                                            .setColor(client.color)
                                    ],
                                    flags: MessageFlags.Ephemeral
                                });

                                const allKeys = fields.map(field => field.key);
                                const allLabels = fields.map(field => `${emojis.enabled} **${field.name}**`).join("\n");

                                await client.antinukeDB.set(`antinukeData_${guild.id}.whitelisted.${member.user.id}`, {
                                    events: allKeys,
                                    executorId: message.author.id,
                                    timestamp: Date.now()
                                });

                                await i.editReply({
                                    embeds: [
                                        new EmbedBuilder()
                                            .setDescription(`${emojis.tick} **${member} has been whitelisted for all events**`)
                                            .setColor(client.color)
                                    ]
                                });

                                await sentMessage.edit({
                                    embeds: [
                                        new EmbedBuilder()
                                            .setColor(client.color)
                                            .setAuthor({ name: member.user.username, iconURL: member.user.avatarURL({ size: 1024 }) })
                                            .setDescription(`${emojis.tick} **${member} has been whitelisted for all events**\n\n${emojis.user} **Target:** ${member}\n${emojis.executor} **Executor: ${message.member}**\n\n__**Events**__\n${allLabels}`)
                                            .setFooter({ text: `Executed by ${message.author.username}`, iconURL: message.author.displayAvatarURL() })
                                    ],
                                    components: []
                                });

                                collector.stop();
                            }
                        });


                        return;
                    }

                    case 'remove': {
                        if (!antinukeData?.enabled) {
                            return message.reply({
                                embeds: [
                                    new EmbedBuilder()
                                        .setDescription(`${emojis.warn} **Antinuke is not enabled in this server**`)
                                        .setColor(client.color)
                                ]
                            })
                        }
                        if (!args[2]) {
                            return message.reply({
                                embeds: [
                                    new EmbedBuilder()

                                        .setDescription(`${emojis.warn} **Please mention a valid Member or provide a valid Member ID.**`)
                                        .setColor(client.color)
                                ]
                            })
                        }
                        if (!member) {
                            return message.reply({
                                embeds: [
                                    new EmbedBuilder()

                                        .setDescription(`${emojis.warn} **Please mention a valid Member or provide a valid Member ID.**`)
                                        .setColor(client.color)
                                ]
                            })
                        }

                        let whitelist = antinukeData?.whitelisted || {}

                        if (!whitelist[member.user.id]) {
                            return message.reply({
                                embeds: [
                                    new EmbedBuilder()
                                        .setDescription(`${emojis.warn} **This user is not whitelisted**`)
                                        .setColor(client.color)
                                ]
                            })
                        }

                        await antinukeDB.delete(`antinukeData_${guild.id}.whitelisted.${member.user.id}`)

                        await message.reply({
                            embeds: [
                                new EmbedBuilder()
                                    .setDescription(`${emojis.tick} **Removed ${member} from antinuke whitelist**`)
                                    .setColor(client.color)
                            ]
                        })
                        break;
                    }

                    case 'show': {
                        if (!antinukeData?.enabled) {
                            return message.reply({
                                embeds: [
                                    new EmbedBuilder()
                                        .setDescription(`${emojis.warn} **Antinuke is not enabled in this server**`)
                                        .setColor(client.color)
                                ]
                            })
                        }
                        const whitelistData = await client.antinukeDB.get(`antinukeData_${guild.id}.whitelisted`) || {};
                        const whitelistedUsers = Object.entries(whitelistData);


                        if (whitelistedUsers.length === 0) {
                            return message.reply({
                                embeds: [
                                    new EmbedBuilder()
                                        .setDescription(`${emojis.warn} **No users are currently whitelisted.**`)
                                        .setColor(client.color)
                                ]
                            });
                        }

                        const itemsPerPage = 5;
                        const totalPages = Math.ceil(whitelistedUsers.length / itemsPerPage);

                        const generateEmbed = (pageNum) => {
                            const start = pageNum * itemsPerPage;
                            const end = start + itemsPerPage;
                            const pageItems = whitelistedUsers.slice(start, end);

                            const embed = new EmbedBuilder()
                                .setTitle("Whitelisted Users")
                                .setColor(client.color)
                                .setFooter({ text: `Page ${pageNum + 1} of ${totalPages}` })
                                .setThumbnail(message.guild.iconURL({ size: 1024 }));

                            let description = "";
                            pageItems.forEach(([userId, data]) => {
                                const executor = data?.executorId ? `<@${data.executorId}>` : "Unknown";
                                const timestamp = data?.timestamp ? `<t:${Math.floor(data.timestamp / 1000)}:R>` : "Unknown";
                                description += `<@${userId}> — **Executor:** ${executor} | ${timestamp}\n`;
                            });

                            embed.setDescription(description || "No users found.");
                            return embed;
                        };


                        await paginate(message, whitelistedUsers, itemsPerPage, generateEmbed);
                        return;
                    }

                    case 'reset': {
                        if (!antinukeData?.enabled) {
                            return message.reply({
                                embeds: [
                                    new EmbedBuilder()
                                        .setDescription(`${emojis.warn} **Antinuke is not enabled in this server**`)
                                        .setColor(client.color)
                                ]
                            })
                        }
                        await antinukeDB.set(`antinukeData_${guild.id}.whitelisted`, {})
                        return message.reply({
                            embeds: [
                                new EmbedBuilder()
                                    .setDescription(`${emojis.warn} **Successfully reseted all whitelisted users for this guild.**`)
                                    .setColor(client.color)
                            ]
                        })
                    }

                    default: {
                        return message.reply({
                            embeds: [
                                new EmbedBuilder()
                                    .setAuthor({ name: 'Velyx Antinuke', iconURL: client.user.avatarURL({ size: 1024 }) })
                                    .setDescription(
                                        `**Whitelist Management**\n\n` +
                                        `- \`antinuke whitelist add <member>\`\n└  Adds a whitelist user\n\n` +
                                        `- \`antinuke whitelist remove <member>\`\n└  Removes a whitelist user\n\n` +
                                        `- \`antinuke whitelist show\`\n└  Shows the whitelist users list\n\n` +
                                        `- \`antinuke whitelist reset\`\n└  Resets the whitelist\n\n`
                                    )
                                    .setFooter({ text: `Requested by ${message.author.username}`, iconURL: message.author.avatarURL({ size: 1024 }) })
                                    .setColor(client.color)
                            ]
                        })
                    }
                }
                break;
            }

            case 'logging': {
                if (!antinukeData?.enabled) {
                    return message.reply({
                        embeds: [
                            new EmbedBuilder()
                                .setDescription(`${emojis.warn} **Antinuke is not enabled in this server**`)
                                .setColor(client.color)
                        ]
                    })
                }
                if (!args[1]) {
                    return message.reply({
                        embeds: [
                            new EmbedBuilder()
                                .setDescription(`${emojis.warn} **Please provide a channel mention or ID**`)
                                .setColor(client.color)
                        ]
                    })
                }
                const channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[1]) || await message.guild.channels.fetch(args[1]).catch(() => null)

                if (!channel) {
                    return message.reply({
                        embeds: [
                            new EmbedBuilder()
                                .setDescription(`${emojis.warn} **Please provide a valid channel mention or ID**`)
                                .setColor(client.color)
                        ]
                    })
                }

                await antinukeDB.set(`antinukeData_${guild.id}.logsChannel`, channel.id)

                return message.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setDescription(`${emojis.tick} **Antinuke Logging Channel is set to ${channel}**`)
                            .setColor(client.color)
                    ]
                })
            }

            case 'config': {
                if (!antinukeData?.enabled) {
                    return message.reply({
                        embeds: [
                            new EmbedBuilder()
                                .setDescription(`${emojis.warn} **Antinuke is not enabled in this server**`)
                                .setColor(client.color)
                        ]
                    })
                }

                const whitelistData = antinukeData?.whitelisted || {}
                const whitelistedCount = Object.entries(whitelistData)?.length || 0
                const extraOwnerCount = antinukeData?.extraOwners?.length || 0

                const embed = new EmbedBuilder()
                    .setDescription(
                        `__**${emojis.antinuke} Protection Details**__\n` +
                        `> ${emojis.arrow} **Role:** <@&${antinukeData.protectRole}>\n` +
                        `> ${emojis.arrow} **Default Action:** \`${antinukeData.punishment?.toUpperCase()}\`\n` +
                        `> ${emojis.arrow} **Logging Channel:** ${antinukeData?.logsChannel ? `<#${antinukeData.logsChannel}>` : '`Not Set`'}\n` +
                        `> ${emojis.arrow} **Whitelist Users:** \`${whitelistedCount}\`\n` +
                        `> ${emojis.arrow} **ExtraOwners Count:** \`${extraOwnerCount}\`\n\n` +
                        `__**${emojis.gear} Active Protection Events**__\n` +
                        `> ${emojis.enabled} **Anti Bot**\n` +
                        `> ${emojis.enabled} **Anti Ban**\n` +
                        `> ${emojis.enabled} **Anti Kick**\n` +
                        `> ${emojis.enabled} **Anti Channel Create**\n` +
                        `> ${emojis.enabled} **Anti Channel Delete**\n` +
                        `> ${emojis.enabled} **Anti Channel Update**\n` +
                        `> ${emojis.enabled} **Anti Sticker Create**\n` +
                        `> ${emojis.enabled} **Anti Sticker Delete**\n` +
                        `> ${emojis.enabled} **Anti Sticker Update**\n` +
                        `> ${emojis.enabled} **Anti Guild Update**\n` +
                        `> ${emojis.enabled} **Anti Role Create**\n` +
                        `> ${emojis.enabled} **Anti Role Delete**\n` +
                        `> ${emojis.enabled} **Anti Role Update**\n` +
                        `> ${emojis.enabled} **Anti Unban**\n` +
                        `> ${emojis.enabled} **Anti Webhook Update**\n` +
                        `> ${emojis.enabled} **Anti Member Update**\n` +
                        `> ${emojis.enabled} **Anti Emoji Update**\n` +
                        `> ${emojis.enabled} **Anti Emoji Create**\n` +
                        `> ${emojis.enabled} **Anti Emoji Delete**\n` +
                        `> ${emojis.enabled} **Anti Prune**\n` +
                        `> ${emojis.enabled} **Anti Ping**\n` +
                        `> ${emojis.enabled} ****Auto Recovery****\n\n` +
                        `-# **Note:- Move my "Velyx Protect" role to the top of all roles for the best performance**`
                    ).setColor(client.color)
                    .setAuthor({ name: 'Velyx Antinuke System', iconURL: client.user.avatarURL({ size: 1024 }) })
                    .setFooter({ text: `Requested by ${message.author.username}`, iconURL: message.author.displayAvatarURL({ size: 1024 }) })
                    .setThumbnail(message.guild.iconURL({ size: 1024 }))

                await message.reply({ embeds: [embed] })
                break
            }

            case 'punishment': {
                if (!antinukeData?.enabled) {
                    return message.reply({
                        embeds: [
                            new EmbedBuilder()
                                .setDescription(`${emojis.warn} **Antinuke is not enabled in this server**`)
                                .setColor(client.color)
                        ]
                    })
                }

                if (!action) {
                    const embed = new EmbedBuilder()
                        .setAuthor({ name: 'Velyx Antinuke Punishment', iconURL: client.user.avatarURL({ size: 1024 }) })
                        .setDescription(
                            `- \`antinuke punishment set\`\n└  Sets the punishment of antinuke system\n\n` +
                            `- \`antinuke punishment show\`\n└  Show the current punishment of antinuke system`
                        )
                        .setFooter({ text: `Requested by ${message.author.username}`, iconURL: message.author.avatarURL({ size: 1024 }) })
                        .setThumbnail(client.user.avatarURL({ size: 1024 }))
                        .setColor(client.color)
                    return message.reply({ embeds: [embed] })
                }

                switch (action) {
                    case 'set': {
                        const selectMenu = new StringSelectMenuBuilder()
                            .setCustomId('select_action')
                            .setPlaceholder('Select action')
                            .setMinValues(1)
                            .setMaxValues(1)
                            .addOptions(
                                { label: 'Kick', emoji: emojis.rmv, value: 'kick' },
                                { label: 'Ban', emoji: emojis.ban, value: 'ban' }
                            );

                        const row = new ActionRowBuilder().addComponents(selectMenu);

                        const embed = new EmbedBuilder()
                            .setColor(client.color)
                            .setAuthor({ name: 'Velyx Antinuke', iconURL: client.user.avatarURL({ size: 1024 }) })
                            .setTitle('Antinuke Action Configuration')
                            .setDescription(`${emojis.antinuke} **Choose the action that should be enforced when a security event is detected.**\n\n-# **Note:- Move my "Velyx Protect" role to the top of all roles for the best performance**`)
                            .setThumbnail(message.guild.iconURL({ size: 1024 }))



                        const sentMessage = await message.reply({ embeds: [embed], components: [row] });


                        const collector = sentMessage.createMessageComponentCollector({ time: 60000 });
                        let selectedAction;
                        collector.on('collect', async (interaction) => {
                            if (!interaction.isStringSelectMenu()) return;
                            if (interaction.user.id !== message.author.id) {
                                return i.reply({ content: 'You cannot interact with this.', flags: MessageFlags.Ephemeral });
                            }

                            const { customId, values, guild } = interaction;

                            if (customId === 'select_action') {
                                selectedAction = values[0];

                                try {
                                    await sentMessage.edit({
                                        embeds: [
                                            new EmbedBuilder()
                                                .setAuthor({ name: 'Velyx Antinuke', iconURL: client.user.avatarURL({ size: 1024 }) })
                                                .setDescription(`${emojis.loading} **Configuring the antinuke punishment**`)
                                                .setColor(client.color)
                                        ],
                                        flags: MessageFlags.Ephemeral,
                                        components: []
                                    })

                                    await client.antinukeDB.set(`antinukeData_${guild.id}.punishment`, selectedAction);

                                    await interaction.update({
                                        embeds: [
                                            new EmbedBuilder()
                                                .setAuthor({ name: 'Velyx Antinuke', iconURL: client.user.avatarURL({ size: 1024 }) })
                                                .setColor(client.color)
                                                .setDescription(`${emojis.tick} Antinuke action has been set to **${selectedAction}**`)
                                        ],
                                        components: [],
                                        flags: MessageFlags.Ephemeral
                                    });

                                    collector.stop();
                                } catch (error) {
                                    console.error('Failed to set antinuke action:', error);
                                    await interaction.followUp({
                                        content: `${emojis.cross} **An error occurred while setting the antinuke action.**`,
                                        flags: MessageFlags.Ephemeral
                                    });
                                }
                            }
                        });


                        collector.on('end', async () => {
                            if (!selectedAction) {
                                await sentMessage.edit({
                                    embeds: [
                                        new EmbedBuilder()
                                            .setColor(client.color)
                                            .setDescription(`${emojis.warn} **Antinuke action setup timed out.**`)
                                    ], components: []
                                });
                            }
                        });
                        return
                    }

                    case 'show': {
                        const action = antinukeData?.punishment

                        return message.reply({
                            embeds: [
                                new EmbedBuilder()
                                    .setAuthor({ name: 'Velyx Antinuke', iconURL: client.user.avatarURL({ size: 1024 }) })
                                    .setDescription(`${emojis.antinuke} **Antinuke System punishment is currently set to ${action === 'kick' ? `\`Kick\` ${emojis.rmv}` : `\`Ban\` ${emojis.ban}`}**`)
                                    .setColor(client.color)
                            ]
                        })
                    }

                    default: {
                        const embed = new EmbedBuilder()
                            .setAuthor({ name: 'Velyx Antinuke Punishment', iconURL: client.user.avatarURL({ size: 1024 }) })
                            .setDescription(
                                `- \`antinuke punishment set\`\n└  Sets the punishment of antinuke system\n\n` +
                                `- \`antinuke punishment show\`\n└  Show the current punishment of antinuke system`
                            )
                            .setFooter({ text: `Requested by ${message.author.username}`, iconURL: message.author.avatarURL({ size: 1024 }) })
                            .setThumbnail(client.user.avatarURL({ size: 1024 }))
                            .setColor(client.color)
                        return message.reply({ embeds: [embed] })
                    }
                }
            }

            default:
                return message.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setAuthor({ name: 'Velyx Antinuke', iconURL: client.user.avatarURL({ size: 1024 }) })
                            .setDescription(
                                `- \`antinuke enable\`\n└  Enable the antinuke system\n\n` +
                                `- \`antinuke disable\`\n└  Disable the antinuke system\n\n` +
                                `- \`antinuke whitelist\`\n└  Manage whitelisted users\n\n` +
                                `- \`antinuke extraowner\`\n└  Manage extraOwners\n\n` +
                                `- \`antinuke punishment\`\n└  Sets the punishment of antinuke\n\n` +
                                `- \`antinuke logging\`\n└  Manage antinuke logs\n\n` +
                                `- \`antinuke config\`\n└  View current antinuke settings`
                            )
                            .setFooter({ text: `Requested by ${message.author.username}`, iconURL: message.author.avatarURL({ size: 1024 }) })
                            .setThumbnail(client.user.avatarURL({ size: 1024 }))
                            .setColor(client.color)
                    ]
                })
        }
    }
}