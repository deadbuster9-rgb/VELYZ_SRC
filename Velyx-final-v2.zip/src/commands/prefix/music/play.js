import emojis from '../../../config/emojis.js';

// Wait until player voice connection is ready
function waitForConnection(player, ms = 5000) {
    return new Promise((resolve, reject) => {
        const start = Date.now();
        const check = setInterval(() => {
            if (player.connected) {
                clearInterval(check);
                return resolve();
            }
            if (Date.now() - start > ms) {
                clearInterval(check);
                return reject(new Error('Voice connection timed out.'));
            }
        }, 100);
    });
}

export const data = {
    name: 'play', aliases: ['p'], category: 'music', cooldown: 3,
    args: [{ name: 'query', description: 'Song name or URL', required: true }],
    async execute(message, args, client) {
        const query = args.join(' ');
        if (!query) return message.reply(`${emojis.warn} Provide a song name or URL!`);
        const vc = message.member.voice.channel;
        if (!vc) return message.reply(`${emojis.warn} You need to be in a voice channel!`);

        try {
            const player = client.riffy.createConnection({
                guildId: message.guild.id,
                voiceChannel: vc.id,
                textChannel: message.channel.id,
                deaf: true,
            });

            const resolve = await client.riffy.resolve({ query, requester: message.author });
            const { loadType, tracks, playlistInfo } = resolve;

            if (!tracks?.length) return message.reply(`${emojis.cross} No results found for **${query}**`);

            if (loadType === 'playlist') {
                for (const t of tracks) { t.info.requester = message.author; player.queue.add(t); }
                if (!player.playing && !player.paused) {
                    await waitForConnection(player).catch(() => {});
                    player.play().catch(() => {});
                }
                return message.reply(`${emojis.tick} Added **${tracks.length}** tracks from **${playlistInfo.name}** to the queue.`);
            }

            const track = tracks[0];
            track.info.requester = message.author;
            player.queue.add(track);

            if (!player.playing && !player.paused) {
                await waitForConnection(player).catch(() => {});
                player.play().catch(() => {});
            }

            await message.reply(`${emojis.playing} Added to queue: **${track.info.title}** by **${track.info.author}**`);
        } catch (err) {
            message.reply(`${emojis.cross} Error: ${err.message}`).catch(() => {});
        }
    }
};
