import emojis from '../../../config/emojis.js';
export const data = {
    name: 'volume', aliases: ['vol', 'v'], category: 'music', cooldown: 3,
    async execute(message, args, client) {
        const player = client.riffy.players.get(message.guild.id);
        if (!player) return message.reply(`${emojis.warn} No active session.`);
        if (!args[0]) return message.reply(`🔊 Current volume: **${player.volume}%**`);
        const lvl = parseInt(args[0]);
        if (isNaN(lvl) || lvl < 0 || lvl > 100) return message.reply(`${emojis.warn} Volume must be 0–100.`);
        player.setVolume(lvl);
        const icon = lvl===0?'🔇':lvl<=30?'🔈':lvl<=70?'🔉':'🔊';
        await message.reply(`${icon} Volume set to **${lvl}%**`);
    }
};
