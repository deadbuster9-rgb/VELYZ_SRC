import emojis from '../../../config/emojis.js';
export const data = {
    name: 'stop', aliases: ['leave', 'dc'], category: 'music', cooldown: 3,
    async execute(message, args, client) {
        const player = client.riffy.players.get(message.guild.id);
        if (!player) return message.reply(`${emojis.warn} No active music session.`);
        player.destroy();
        await message.reply(`${emojis.tick} Stopped music and left the channel.`);
    }
};
