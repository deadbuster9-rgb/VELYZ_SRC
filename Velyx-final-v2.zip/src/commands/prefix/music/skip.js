import emojis from '../../../config/emojis.js';
export const data = {
    name: 'skip', aliases: ['s', 'next'], category: 'music', cooldown: 3,
    async execute(message, args, client) {
        const player = client.riffy.players.get(message.guild.id);
        if (!player?.playing) return message.reply(`${emojis.warn} Nothing is playing right now.`);
        player.stop();
        await message.reply(`${emojis.tick} Skipped the current track.`);
    }
};
