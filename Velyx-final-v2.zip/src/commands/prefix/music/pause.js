import emojis from '../../../config/emojis.js';
export const data = {
    name: 'pause', category: 'music', cooldown: 3,
    async execute(message, args, client) {
        const player = client.riffy.players.get(message.guild.id);
        if (!player?.playing) return message.reply(`${emojis.warn} Nothing is playing.`);
        if (player.paused) return message.reply(`${emojis.warn} Already paused.`);
        player.pause(true);
        await message.reply('⏸️ Paused the track.');
    }
};
