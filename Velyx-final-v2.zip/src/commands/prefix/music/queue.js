import emojis from '../../../config/emojis.js';
function fmt(ms) { const s=Math.floor(ms/1000); return `${Math.floor(s/60)}:${(s%60).toString().padStart(2,'0')}`; }
export const data = {
    name: 'queue', aliases: ['q'], category: 'music', cooldown: 3,
    async execute(message, args, client) {
        const player = client.riffy.players.get(message.guild.id);
        if (!player || !player.queue.length)
            return message.reply(`${emojis.warn} The queue is empty.`);
        const tracks = [...player.queue].slice(0, 10);
        const list = tracks.map((t, i) => `**${i+1}.** ${t.info.title} — \`${fmt(t.info.length)}\``).join('\n');
        await message.reply(`🎵 **Music Queue** (${player.queue.length} tracks)\n\n${list}${player.queue.length > 10 ? `\n*...and ${player.queue.length-10} more*` : ''}`);
    }
};
