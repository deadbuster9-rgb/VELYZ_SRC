import emojis from '../../../config/emojis.js';
export const data = {
    name: 'shuffle', category: 'music', cooldown: 3,
    async execute(message, args, client) {
        const player = client.riffy.players.get(message.guild.id);
        if (!player || player.queue.length < 2)
            return message.reply(`${emojis.warn} Need at least 2 tracks in queue to shuffle.`);
        player.queue.shuffle();
        await message.reply(`🔀 Queue shuffled! (${player.queue.length} tracks)`);
    }
};
