import emojis from '../../../config/emojis.js';
export const data = {
    name: 'seek', category: 'music', cooldown: 3,
    args: [{ name: 'position', description: 'Time e.g. 1:30', required: true }],
    async execute(message, args, client) {
        const player = client.riffy.players.get(message.guild.id);
        if (!player?.playing) return message.reply(`${emojis.warn} Nothing is playing.`);
        const pos = args[0];
        const match = pos?.match(/^(\d{1,2}):([0-5]\d)$/);
        if (!match) return message.reply(`${emojis.warn} Use format \`m:ss\` e.g. \`1:30\``);
        const ms = (parseInt(match[1])*60 + parseInt(match[2])) * 1000;
        player.seek(ms);
        await message.reply(`⏩ Seeked to **${pos}**`);
    }
};
