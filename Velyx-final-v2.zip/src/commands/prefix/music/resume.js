import emojis from '../../../config/emojis.js';
export const data = {
    name: 'resume', aliases: ['unpause'], category: 'music', cooldown: 3,
    async execute(message, args, client) {
        const player = client.riffy.players.get(message.guild.id);
        if (!player) return message.reply(`${emojis.warn} No active session.`);
        if (!player.paused) return message.reply(`${emojis.warn} Not paused.`);
        player.pause(false);
        await message.reply('▶️ Resumed the track.');
    }
};
