import emojis from '../../../config/emojis.js';
function fmt(ms) { const s=Math.floor(ms/1000); return `${Math.floor(s/60)}:${(s%60).toString().padStart(2,'0')}`; }
export const data = {
    name: 'nowplaying', aliases: ['np', 'current'], category: 'music', cooldown: 3,
    async execute(message, args, client) {
        const player = client.riffy.players.get(message.guild.id);
        if (!player?.current) return message.reply(`${emojis.warn} Nothing is playing right now.`);
        const t = player.current;
        const pos = player.position || 0;
        const dur = t.info.length || 0;
        const prog = dur > 0 ? Math.floor((pos/dur)*20) : 0;
        const bar = '▓'.repeat(prog) + '░'.repeat(20 - prog);
        await message.reply(
            `${emojis.playing} **Now Playing**\n` +
            `**${t.info.title}** by **${t.info.author}**\n` +
            `\`${fmt(pos)} [${bar}] ${fmt(dur)}\``
        );
    }
};
