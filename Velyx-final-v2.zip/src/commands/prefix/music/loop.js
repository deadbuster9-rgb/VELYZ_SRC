import emojis from '../../../config/emojis.js';
export const data = {
    name: 'loop', aliases: ['repeat'], category: 'music', cooldown: 3,
    async execute(message, args, client) {
        const player = client.riffy.players.get(message.guild.id);
        if (!player?.playing) return message.reply(`${emojis.warn} Nothing is playing.`);
        const mode = args[0]?.toLowerCase();
        if (!['none','track','queue','off'].includes(mode))
            return message.reply(`${emojis.warn} Use: \`loop none\`, \`loop track\`, \`loop queue\``);
        const actual = mode === 'off' ? 'none' : mode;
        player.setLoop(actual);
        const labels = { none:'🔄 Loop **disabled**', track:'🔂 Looping **current track**', queue:'🔁 Looping **queue**' };
        await message.reply(labels[actual]);
    }
};
