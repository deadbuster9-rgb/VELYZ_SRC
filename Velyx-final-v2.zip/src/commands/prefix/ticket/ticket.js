import { EmbedBuilder, PermissionFlagsBits } from 'discord.js';
import emojis from '../../../config/emojis.js';

export const data = {
    name: 'ticket',
    aliases: ['t'],
    category: 'ticket',
    cooldown: 5,
    async execute(message, args, client) {
        const db = client.ticketDB;
        const sub = args[0]?.toLowerCase();

        if (!message.member.permissions.has(PermissionFlagsBits.ManageGuild) && !['close','add','remove','rename','transcript'].includes(sub)) {
            return message.reply(`${emojis.cross} You need **Manage Server** permission.`);
        }

        if (!sub) {
            return message.reply(
                `**🎫 Ticket Commands**\n\`\`\`\n` +
                `-ticket add <@user>     — Add user to ticket\n` +
                `-ticket remove <@user>  — Remove user from ticket\n` +
                `-ticket close [reason]  — Close this ticket\n` +
                `-ticket rename <name>   — Rename this ticket\n` +
                `-ticket settings        — View ticket settings\n` +
                `\`\`\``
            );
        }

        if (sub === 'add') {
            const ticketData = await db.get(`ticket_channel_${message.channel.id}`);
            if (!ticketData) return message.reply(`${emojis.cross} This is not a ticket channel.`);
            const user = message.mentions.users.first();
            if (!user) return message.reply(`${emojis.warn} Mention a user to add.`);
            await message.channel.permissionOverwrites.edit(user.id, { ViewChannel: true, SendMessages: true, ReadMessageHistory: true });
            return message.reply(`${emojis.tick} Added **${user.username}** to the ticket.`);
        }

        if (sub === 'remove') {
            const ticketData = await db.get(`ticket_channel_${message.channel.id}`);
            if (!ticketData) return message.reply(`${emojis.cross} This is not a ticket channel.`);
            const user = message.mentions.users.first();
            if (!user) return message.reply(`${emojis.warn} Mention a user to remove.`);
            if (user.id === ticketData.userId) return message.reply(`${emojis.cross} Cannot remove the ticket owner.`);
            await message.channel.permissionOverwrites.delete(user.id);
            return message.reply(`${emojis.tick} Removed **${user.username}** from the ticket.`);
        }

        if (sub === 'close') {
            const { closeTicket } = await import('../../slash/ticket/ticket.js');
            const ticketData = await db.get(`ticket_channel_${message.channel.id}`);
            if (!ticketData) return message.reply(`${emojis.cross} This is not a ticket channel.`);
            const reason = args.slice(1).join(' ') || 'No reason provided';
            await message.reply(`${emojis.loading} Closing ticket...`);
            await closeTicket(message.channel, message.author, reason, client, db);
            return;
        }

        if (sub === 'rename') {
            const ticketData = await db.get(`ticket_channel_${message.channel.id}`);
            if (!ticketData) return message.reply(`${emojis.cross} This is not a ticket channel.`);
            const name = args.slice(1).join('-').toLowerCase().replace(/\s+/g, '-');
            if (!name) return message.reply(`${emojis.warn} Provide a new name.`);
            await message.channel.setName(name);
            return message.reply(`${emojis.tick} Renamed to **${name}**`);
        }

        if (sub === 'settings') {
            const config = await db.get(`ticket_config_${message.guild.id}`);
            if (!config) return message.reply(`${emojis.cross} Ticket system not configured. Use \`/ticket setup\`.`);
            const embed = new EmbedBuilder()
                .setColor(client.color)
                .setTitle('🎫 Ticket Settings')
                .addFields(
                    { name: '📁 Category', value: `<#${config.categoryId}>`, inline: true },
                    { name: '🛡️ Support Role', value: `<@&${config.supportRoleId}>`, inline: true },
                    { name: '👑 Admin Role', value: `<@&${config.adminRoleId}>`, inline: true },
                    { name: '📋 Log Channel', value: `<#${config.logChannelId}>`, inline: true },
                    { name: '📄 Transcript', value: `<#${config.transcriptChannelId}>`, inline: true },
                    { name: '🎟️ Total Tickets', value: `${config.ticketCount || 0}`, inline: true },
                );
            return message.reply({ embeds: [embed] });
        }
    }
};
