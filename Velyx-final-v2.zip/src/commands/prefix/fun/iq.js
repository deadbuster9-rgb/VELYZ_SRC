export const data = {
    name: 'iq', aliases: ['iqtest'], category: 'fun', cooldown: 5,
    async execute(message, args, client) {
        const user = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author;
        const iq = Math.floor(Math.random() * 200) + 1;
        const msg = iq>=160?'🧠 Genius level.':iq>=130?'📚 Very smart.':iq>=110?'💡 Above average.':iq>=90?'🙂 Average.':iq>=70?'😬 A bit below average.':'🪨 Rock-level IQ.';
        await message.reply(`**IQ test result for ${user}**\n\`\`\`\nIQ Score: ${iq}\n\`\`\`${msg}`);
    }
};
