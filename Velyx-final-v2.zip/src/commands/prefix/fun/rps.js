const choices = ['🪨 Rock','📄 Paper','✂️ Scissors'];
const wins = { '🪨 Rock':'✂️ Scissors','📄 Paper':'🪨 Rock','✂️ Scissors':'📄 Paper' };
export const data = {
    name: 'rps', aliases: ['rockpaperscissors'], category: 'fun', cooldown: 3,
    async execute(message, args, client) {
        const input = args[0]?.toLowerCase();
        const map = { rock:'🪨 Rock', paper:'📄 Paper', scissors:'✂️ Scissors', r:'🪨 Rock', p:'📄 Paper', s:'✂️ Scissors' };
        const player = map[input];
        if (!player) return message.reply('❌ Choose: `rock`, `paper`, or `scissors`');
        const bot = choices[Math.floor(Math.random()*3)];
        const result = player===bot?'🤝 **Tie!**':wins[player]===bot?'🎉 **You win!**':'💀 **You lose!**';
        await message.reply(`You: **${player}** vs Me: **${bot}**\n${result}`);
    }
};
