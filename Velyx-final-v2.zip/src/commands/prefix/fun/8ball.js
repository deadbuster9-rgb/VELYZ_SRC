const answers = ['🎱 It is certain.','🎱 Without a doubt.','🎱 Yes, definitely.','🎱 Most likely.','🎱 Outlook good.','🎱 Yes.','🎱 Signs point to yes.','🎱 Reply hazy, try again.','🎱 Ask again later.','🎱 Cannot predict now.','🎱 Don\'t count on it.','🎱 My reply is no.','🎱 My sources say no.','🎱 Outlook not so good.','🎱 Very doubtful.'];
export const data = {
    name: '8ball', aliases: ['magic8ball', 'eightball'], category: 'fun', cooldown: 3,
    args: [{ name: 'question', description: 'Your question', required: true }],
    async execute(message, args, client) {
        const q = args.join(' ');
        if (!q) return message.reply('❌ Ask a question! e.g. `-8ball Will I be rich?`');
        await message.reply(`**❓ ${q}**\n${answers[Math.floor(Math.random() * answers.length)]}`);
    }
};
