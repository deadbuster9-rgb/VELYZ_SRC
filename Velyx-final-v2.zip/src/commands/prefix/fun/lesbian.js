export const data = {
    name: 'lesbian', aliases: ['lesbianmeter'], category: 'fun', cooldown: 5,
    async execute(message, args, client) {
        const user = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author;
        const pct = Math.floor(Math.random() * 101);
        const bar = '█'.repeat(Math.floor(pct/10)) + '░'.repeat(10 - Math.floor(pct/10));
        const msg = pct>=90?'🌸 Full lesbian energy.':pct>=70?'🌺 Strong lesbian vibes.':pct>=50?'🌷 The energy is there.':pct>=30?'💐 Maybe a little bit?':'🌿 Not so much, but respect.';
        await message.reply(`**Lesbian meter for ${user}**\n\`\`\`\n[${bar}] ${pct}%\n\`\`\`${msg}`);
    }
};
