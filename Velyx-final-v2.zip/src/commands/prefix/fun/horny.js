export const data = {
    name: 'horny', aliases: ['hornymeter'], category: 'fun', cooldown: 5,
    async execute(message, args, client) {
        const user = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author;
        const pct = Math.floor(Math.random() * 101);
        const bar = '█'.repeat(Math.floor(pct/10)) + '░'.repeat(10 - Math.floor(pct/10));
        const msg = pct>=90?'🚨 Send help.':pct>=70?'😳 Cold shower needed.':pct>=50?'👀 Sus activity.':pct>=30?'🙂 Pretty normal.':'😇 Pure soul.';
        await message.reply(`**Horny meter for ${user}**\n\`\`\`\n[${bar}] ${pct}%\n\`\`\`${msg}`);
    }
};
