const roasts = ['You are the human equivalent of a participation trophy.','You have the personality of a damp sock.','I\'d say you\'re dull but that would be an insult to dishwater.','You are the reason God invented mute buttons.','Your opinion is like a broken pencil — pointless.','I\'d roast you harder but my mom said I can\'t burn trash.','You are living proof that evolution can go in reverse.','I\'d call you a tool but even tools are useful.','You\'re the type to trip over a wireless router.','Your vibe is just "error 404 personality not found".'];
export const data = {
    name: 'roast', aliases: ['burn'], category: 'fun', cooldown: 5,
    async execute(message, args, client) {
        const user = message.mentions.users.first() || message.author;
        await message.reply(`🔥 **${user.username}**, ${roasts[Math.floor(Math.random() * roasts.length)]}`);
    }
};
