export const data = {
    name: 'sigma', aliases: ['grindset'], category: 'fun', cooldown: 5,
    async execute(message, args, client) {
        const user = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author;
        const pct = Math.floor(Math.random() * 101);
        const bar = '█'.repeat(Math.floor(pct/10)) + '░'.repeat(10 - Math.floor(pct/10));
        const msg = pct>=95?'😤 Lone wolf. Pure grindset.':pct>=80?'💪 Very sigma. Hustle never stops.':pct>=60?'🔥 Sigma energy present.':pct>=40?'📈 Some sigma potential.':pct>=20?'😐 More beta than sigma.':'🥀 Full beta. Touch grass.';
        await message.reply(`**Sigma grindset meter for ${user}**\n\`\`\`\n[${bar}] ${pct}%\n\`\`\`${msg}`);
    }
};
