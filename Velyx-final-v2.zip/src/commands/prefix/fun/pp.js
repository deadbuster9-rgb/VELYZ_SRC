export const data = {
    name: 'pp', aliases: ['ppsize'], category: 'fun', cooldown: 5,
    async execute(message, args, client) {
        const user = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author;
        const size = Math.floor(Math.random() * 15);
        const pp = `8${'='.repeat(size)}D`;
        const msg = size>=12?'😱 Massive.':size>=9?'😳 Big energy.':size>=6?'🙂 Decent.':size>=3?'😬 Motion of the ocean.':'🔬 Microscope needed.';
        await message.reply(`**PP size for ${user}**\n\`\`\`\n${pp}\n\`\`\`${msg}`);
    }
};
