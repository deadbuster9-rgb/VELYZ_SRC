export const data = {
    name: 'ship', aliases: ['love', 'lovecalc'], category: 'fun', cooldown: 5,
    args: [{ name: 'user1', description: 'First user', required: true }, { name: 'user2', description: 'Second user', required: true }],
    async execute(message, args, client) {
        const u1 = message.mentions.users.first() || client.users.cache.get(args[0]);
        const u2 = message.mentions.users.at(1) || client.users.cache.get(args[1]);
        if (!u1 || !u2) return message.reply('❌ Mention two users! e.g. `-ship @user1 @user2`');
        const pct = Math.floor(Math.random() * 101);
        const bar = '█'.repeat(Math.floor(pct/10)) + '░'.repeat(10 - Math.floor(pct/10));
        const msg = pct>=90?'💍 Perfect match!':pct>=70?'💕 Strong connection.':pct>=50?'😊 Could work!':pct>=30?'😬 Situationship energy.':'💔 Zero chemistry.';
        await message.reply(`**${u1.username} ❤️ ${u2.username}**\n\`\`\`\n[${bar}] ${pct}%\n\`\`\`${msg}`);
    }
};
