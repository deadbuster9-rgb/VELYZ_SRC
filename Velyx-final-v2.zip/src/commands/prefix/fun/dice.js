export const data = {
    name: 'dice', aliases: ['roll', 'rolldice'], category: 'fun', cooldown: 3,
    async execute(message, args, client) {
        const sides = parseInt(args[0]) || 6;
        if (sides < 2 || sides > 100) return message.reply('❌ Dice must have between 2 and 100 sides.');
        await message.reply(`🎲 Rolled a **${sides}**-sided dice: **${Math.floor(Math.random() * sides) + 1}**`);
    }
};
