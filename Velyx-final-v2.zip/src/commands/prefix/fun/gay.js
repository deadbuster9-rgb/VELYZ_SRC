export const data = {
    name: 'gay', aliases: ['gaymeter'], category: 'fun', cooldown: 5,
    async execute(message, args, client) {
        const user = message.mentions.users.first() || client.users.cache.get(args[0]) || message.author;
        const pct = Math.floor(Math.random() * 101);
        const bar = '█'.repeat(Math.floor(pct/10)) + '░'.repeat(10 - Math.floor(pct/10));
        const msg = pct>=90?'🌈 Ultra gay. Absolutely fabulous.':pct>=70?'🏳️‍🌈 Pretty gay honestly.':pct>=50?'😳 Kinda gay ngl.':pct>=30?'🤔 A little curious maybe?':'😐 Probably straight. Maybe.';
        await message.reply(`**Gay meter for ${user}**\n\`\`\`\n[${bar}] ${pct}%\n\`\`\`${msg}`);
    }
};
