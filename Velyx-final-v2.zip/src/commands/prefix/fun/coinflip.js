export const data = {
    name: 'coinflip', aliases: ['flip', 'coin'], category: 'fun', cooldown: 3,
    async execute(message, args, client) {
        await message.reply(Math.random() < 0.5 ? '🪙 **Heads!**' : '🪙 **Tails!**');
    }
};
