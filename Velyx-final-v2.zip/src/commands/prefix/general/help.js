import {
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    EmbedBuilder,
    MessageFlags,
    StringSelectMenuBuilder,
    ComponentType,
    Message,
} from "discord.js";
import emojis from "../../../config/emojis.js";
import config from "../../../config/config.js";

export const data = {
    name: "help",
    description: "Get a list of all commands",
    aliases: ['h'],
    /**
     * 
     * @param {Message} message 
     * @param {String[]} args 
     * @param {import('../../../base/Velyx.js').Velyx} client 
     */
    async execute(message, args, client) {
        const dev = client.config.owners?.[0]
            ? (client.users.cache.get(client.config.owners[0]) || { username: "Velyx Dev", avatarURL: () => null })
            : { username: "Velyx Dev", avatarURL: () => null };

        const prefix =
            (await client.prefixDB.get(`${message.guild.id}`)) ||
            config.prefix;

        const countPrefixCommands = () => {
            let count = 0;
            client.prefix.forEach((cmd) => {
                count +=
                    typeof cmd.subCommandCount === "number" && cmd.subCommandCount > 0
                        ? cmd.subCommandCount
                        : 1;
            });
            return 120;
        };

        const totalCommands = countPrefixCommands();

        const mainEmbed = new EmbedBuilder()
            .setAuthor({
                name: `${client.user.username} - Help Menu`,
                iconURL: client.user.displayAvatarURL({ size: 1024 }),
            })
            .setDescription(
                `> **Velyx - Your Multipurpose Server Bot**\n\n` +
                `${emojis.yellow_dot} **Default Prefix:** \`-\`\n` +
                `${emojis.yellow_dot} **In Server Prefix:** \`${prefix}\`\n` +
                `${emojis.yellow_dot} **Total Commands:** \`${totalCommands}\`\n` +
                `${emojis.yellow_dot} **Select a category from the menu below.**\n\n` +
                "```css\n<> - Required Argument\n[] - Optional Argument\n```"
            )
            .setThumbnail(client.user.displayAvatarURL({ size: 1024 }))
            .addFields({
                name: `${emojis.module} **Main Modules**`,
                value: [
                    `> ${emojis.antinuke} \`\`:\`\` **Antinuke**`,
                    `> ${emojis.automod} \`\`:\`\` **AutoMod**`,
                    `> ${emojis.moderation} \`\`:\`\` **Moderation**`,
                    `> ${emojis.h_general} \`\`:\`\` **General**`,
                    `> ${emojis.h_giveaway} \`\`:\`\` **Giveaway**`,
                    `> ${emojis.ignore} \`\`:\`\` **Ignore**`,
                    `> ${emojis.autoreact} \`\`:\`\` **Auto React**`,
                    `> ${emojis.autorole} \`\`:\`\` **Auto Roles**`,
                    `> ${emojis.activityroles} \`\`:\`\` **Activity Roles**`,
                    `> ${emojis.media} \`\`:\`\` **Media**`,
                    `> ${emojis.voice} \`\`:\`\` **Voice**`,
                    `> ${emojis.autoresponder} \`\`:\`\` **Auto Responder**`,
                    `> ${emojis.gear} \`\`:\`\` **Join to Create**`,
                    `> ${emojis.greet} \`\`:\`\` **Welcome**`,
                    `> ${emojis.logging} \`\`:\`\` **Logging**`,
                ].join("\n"),
            })
            .setColor(client.color)
            .setFooter({
                text: `Made by ${dev.username}`,
                iconURL: dev.avatarURL?.({ size: 1024 }) ?? undefined,
            });

        const menu = new StringSelectMenuBuilder()
            .setCustomId("help_menu")
            .setPlaceholder("Select a module to view commands")
            .addOptions([
                { label: "Home", value: "home", emoji: emojis.home },
                { label: "Antinuke", value: "antinuke", emoji: emojis.antinuke },
                { label: "AutoMod", value: "automod", emoji: emojis.automod },
                { label: "Moderation", value: "moderation", emoji: emojis.moderation },
                { label: "General", value: "general", emoji: emojis.h_general },
                { label: "Giveaway", value: "giveaway", emoji: emojis.h_giveaway },
                { label: "Ignore", value: "ignore", emoji: emojis.ignore },
                { label: "Auto React", value: "autoreact", emoji: emojis.autoreact },
                { label: "Auto Roles", value: "autoroles", emoji: emojis.autorole },
                { label: "Activity Roles", value: "activityrole", emoji: emojis.activityroles },
                { label: "Media", value: "media", emoji: emojis.media },
                { label: "Voice", value: "voice", emoji: emojis.voice },
                { label: "Auto Responder", value: "autoresponder", emoji: emojis.autoresponder },
                { label: "Join to Create", value: "j2c", emoji: emojis.gear },
                { label: "Welcome", value: "welcome", emoji: emojis.greet },
                { label: "Logging", value: "logging", emoji: emojis.logging },
            ]);

        const row = new ActionRowBuilder().addComponents(menu);
        const disabledRow = new ActionRowBuilder().addComponents(
            new StringSelectMenuBuilder()
            .setCustomId("help_menu")
            .setPlaceholder("Select a module to view commands")
            .addOptions([
                { label: "Home", value: "home", emoji: emojis.home },
                { label: "Antinuke", value: "antinuke", emoji: emojis.antinuke },
                { label: "AutoMod", value: "automod", emoji: emojis.automod },
                { label: "Moderation", value: "moderation", emoji: emojis.moderation },
                { label: "General", value: "general", emoji: emojis.h_general },
                { label: "Giveaway", value: "giveaway", emoji: emojis.h_giveaway },
                { label: "Ignore", value: "ignore", emoji: emojis.ignore },
                { label: "Auto React", value: "autoreact", emoji: emojis.autoreact },
                { label: "Auto Roles", value: "autoroles", emoji: emojis.autorole },
                { label: "Activity Roles", value: "activityrole", emoji: emojis.activityroles },
                { label: "Media", value: "media", emoji: emojis.media },
                { label: "Voice", value: "voice", emoji: emojis.voice },
                { label: "Auto Responder", value: "autoresponder", emoji: emojis.autoresponder },
                { label: "Join to Create", value: "j2c", emoji: emojis.gear },
                { label: "Welcome", value: "welcome", emoji: emojis.greet },
                { label: "Logging", value: "logging", emoji: emojis.logging },
            ]).setDisabled(true)
        );

        const buttons = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setLabel("Support Server")
                .setStyle(ButtonStyle.Link)
                .setURL(config.links.supportServer),
            new ButtonBuilder()
                .setLabel("Invite Me")
                .setStyle(ButtonStyle.Link)
                .setURL(
                    `https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot+applications.commands`
                )
        );

        const msg = await message.reply({
            embeds: [mainEmbed],
            components: [row, buttons],
        });

        const collector = msg.createMessageComponentCollector({
            componentType: ComponentType.StringSelect,
            time: 200_000,
        });

        collector.on("collect", async (i) => {
            if (i.user.id !== message.author.id) {
                return i.reply({
                    content: `This menu is not for you!`,
                    flags: MessageFlags.Ephemeral,
                });
            }

            const category = i.values[0];

            if (category === "home") {
                return i.update({
                    embeds: [mainEmbed],
                    components: [row, buttons],
                });
            }

            const commandsMap = {
                antinuke: [
                    "antinuke", "antinuke enable", "antinuke disable", "antinuke whitelist add", "antinuke whitelist remove",
                    "antinuke whitelist show", "antinuke whitelist reset", "antinuke extraowner add", "antinuke extraowner remove",
                    "antinuke extraowner show", "antinuke extraowner reset", "antinuke logging", "antinuke punishment set",
                    "antinuke punishment show", "antinuke config"
                ],
                automod: [],
                moderation: ['ban', 'unban', 'unbanall', 'purge', 'purge all', 'purge bots', 'purge files', 'purge images',
                    'purge user', 'purge emojis', 'purge contains', 'purge embeds', 'kick', 'lock', 'unlock', 'unlockall', 'lockall',
                    'hide', 'unhideall', 'mute', 'unmute', 'unmuteall', 'nick', 'warn', 'snipe', 'role add', 'role remove', 'steal'],
                general: ['help', 'ping', 'avatar', 'banner', 'afk', 'profile', 'setprefix', 'serverinfo', 'stats', 'userinfo', 'invite', 'support', 'status'],
                giveaway: ['gstart', 'gend', 'greroll', 'gjoins'],
                ignore: ['ignore', 'ignore channel add', 'ignore channel remove', 'ignore channel show', 'ignore channel reset',
                    'ignore bypass add', 'ignore bypass remove', 'ignore bypass show', 'ignore bypass reset'],
                autoreact: ['autoreact', 'autoreact add', 'autoreact remove', 'autoreact show', 'autoreact reset'],
                autoroles: ['autoroles', 'autoroles add', 'autoroles remove', 'autoroles list'],
                activityrole: ['activityrole', 'activityrole add', 'activityrole remove', 'activityrole list'],
                media: ['media', 'media channel add', 'media channel remove', 'media channel list', 'media channel reset',
                    'media bypass add', 'media bypass remove', 'media bypass list', 'media bypass reset'],
                voice: ['voice', 'voice lock', 'voice unlock', 'voice mute', 'voice unmute'],
                autoresponder: ['autoresponder', 'autoresponder add', 'autoresponder remove', 'autoresponder list'],
                j2c: ['j2c', 'j2c set', 'j2c disable'],
                welcome: ['welcome', 'welcome set', 'welcome test', 'welcome disable'],
                logging: ['logging', 'logging set', 'logging remove', 'logging show'],
            };

            const cmds = commandsMap[category] ?? [];
            const display =
                cmds.length > 0
                    ? cmds.map((c) => `\`${c}\``).join(", ")
                    : "*No commands available yet.*";

            const emoji = emojis[category] ?? "📦";
            const embed = new EmbedBuilder()
                .setAuthor({
                    name: `${client.user.username} - Help Menu`,
                    iconURL: client.user.displayAvatarURL({ size: 1024 }),
                })
                .setDescription(`> ${emoji} **${category.charAt(0).toUpperCase() + category.slice(1)} Commands**\n\n${display}`)
                .setColor(client.color);

            await i.update({
                embeds: [embed],
                components: [row, buttons],
            });
        });
    },
};
