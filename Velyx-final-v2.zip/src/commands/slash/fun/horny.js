import { SlashCommandBuilder } from 'discord.js';
export const data = {
    data: new SlashCommandBuilder().setName('horny').setDescription('Check the horny level 😳')
        .addUserOption(o => o.setName('user').setDescription('User to check')),
    category: 'fun',
    async execute(interaction) {
        const user = interaction.options.getUser('user') || interaction.user;
        const pct = Math.floor(Math.random() * 101);
        const bar = '█'.repeat(Math.floor(pct/10)) + '░'.repeat(10 - Math.floor(pct/10));
        const msg =
            pct >= 90 ? '🚨 Send help immediately.' :
            pct >= 70 ? '😳 Someone needs a cold shower.' :
            pct >= 50 ? '👀 Sus activity detected.' :
            pct >= 30 ? '🙂 Pretty normal tbh.' :
            '😇 Pure soul. Angel behavior.';
        await interaction.reply(`**Horny meter for ${user}**\n\`\`\`\n[${bar}] ${pct}%\n\`\`\`${msg}`);
    }
};
