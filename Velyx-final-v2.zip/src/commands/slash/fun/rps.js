import { SlashCommandBuilder } from 'discord.js';
const choices = ['🪨 Rock','📄 Paper','✂️ Scissors'];
const wins = { '🪨 Rock':'✂️ Scissors', '📄 Paper':'🪨 Rock', '✂️ Scissors':'📄 Paper' };
export const data = {
    data: new SlashCommandBuilder().setName('rps').setDescription('Rock Paper Scissors ✂️')
        .addStringOption(o => o.setName('choice').setDescription('Your choice').setRequired(true)
            .addChoices({name:'Rock 🪨',value:'🪨 Rock'},{name:'Paper 📄',value:'📄 Paper'},{name:'Scissors ✂️',value:'✂️ Scissors'})),
    category: 'fun',
    async execute(interaction) {
        const player = interaction.options.getString('choice');
        const bot = choices[Math.floor(Math.random()*3)];
        const result = player===bot ? '🤝 **Tie!**'
            : wins[player]===bot ? '🎉 **You win!**'
            : '💀 **You lose!**';
        await interaction.reply(`You: **${player}** vs Me: **${bot}**\n${result}`);
    }
};
