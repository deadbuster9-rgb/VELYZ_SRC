import { SlashCommandBuilder } from 'discord.js';
const roasts = [
    'You are the human equivalent of a participation trophy.',
    'You have the personality of a damp sock.',
    'I\'d say you\'re dull but that would be an insult to dishwater.',
    'You are the reason God invented mute buttons.',
    'I\'ve seen better arguments in a kindergarten classroom.',
    'You are the WiFi password nobody wants to share.',
    'If brains were gas, you couldn\'t power a scooter around a cheerio.',
    'You are not stupid — you\'re just unlucky when it comes to thinking.',
    'Your opinion is like a broken pencil — pointless.',
    'I\'d roast you harder but my mom said I can\'t burn trash.',
    'You are living proof that evolution can go in reverse.',
    'I\'d call you a tool but even tools are useful.',
    'You\'re the type to trip over a wireless router.',
    'Your vibe is just "error 404 personality not found".',
    'You have something on your chin... no, the third one down.',
];
export const data = {
    data: new SlashCommandBuilder().setName('roast').setDescription('Roast someone 🔥')
        .addUserOption(o => o.setName('user').setDescription('Who to roast').setRequired(true)),
    category: 'fun',
    async execute(interaction) {
        const user = interaction.options.getUser('user');
        if (user.id === interaction.user.id)
            return interaction.reply(`🔥 You want to roast yourself? Respect. Here: *${roasts[Math.floor(Math.random()*roasts.length)]}*`);
        const roast = roasts[Math.floor(Math.random() * roasts.length)];
        await interaction.reply(`🔥 **${user.username}**, ${roast}`);
    }
};
