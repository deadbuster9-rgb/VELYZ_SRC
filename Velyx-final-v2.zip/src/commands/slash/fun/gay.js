import { SlashCommandBuilder } from 'discord.js';
export const data = {
    data: new SlashCommandBuilder().setName('gay').setDescription('Check how gay someone is 🏳️‍🌈')
        .addUserOption(o => o.setName('user').setDescription('User to check')),
    category: 'fun',
    async execute(interaction) {
        const user = interaction.options.getUser('user') || interaction.user;
        const pct = Math.floor(Math.random() * 101);
        const bar = '█'.repeat(Math.floor(pct/10)) + '░'.repeat(10 - Math.floor(pct/10));
        const msg =
            pct >= 90 ? '🌈 Ultra gay. Absolutely fabulous.' :
            pct >= 70 ? '🏳️‍🌈 Pretty gay honestly.' :
            pct >= 50 ? '😳 Kinda gay ngl.' :
            pct >= 30 ? '🤔 A little curious maybe?' :
            '😐 Probably straight. Maybe.';
        await interaction.reply(`**Gay meter for ${user}**\n\`\`\`\n[${bar}] ${pct}%\n\`\`\`${msg}`);
    }
};
