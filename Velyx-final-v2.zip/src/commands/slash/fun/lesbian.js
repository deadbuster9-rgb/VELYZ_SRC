import { SlashCommandBuilder } from 'discord.js';
export const data = {
    data: new SlashCommandBuilder().setName('lesbian').setDescription('Check the lesbian energy 🏳️‍🌈')
        .addUserOption(o => o.setName('user').setDescription('User to check')),
    category: 'fun',
    async execute(interaction) {
        const user = interaction.options.getUser('user') || interaction.user;
        const pct = Math.floor(Math.random() * 101);
        const bar = '█'.repeat(Math.floor(pct/10)) + '░'.repeat(10 - Math.floor(pct/10));
        const msg =
            pct >= 90 ? '🌸 Full lesbian energy. King behavior.' :
            pct >= 70 ? '🌺 Strong lesbian vibes.' :
            pct >= 50 ? '🌷 The energy is there.' :
            pct >= 30 ? '💐 Maybe a little bit?' :
            '🌿 Not so much, but respect.';
        await interaction.reply(`**Lesbian meter for ${user}**\n\`\`\`\n[${bar}] ${pct}%\n\`\`\`${msg}`);
    }
};
