import { SlashCommandBuilder } from 'discord.js';
export const data = {
    data: new SlashCommandBuilder().setName('coinflip').setDescription('Flip a coin 🪙'),
    category: 'fun',
    async execute(interaction) {
        const result = Math.random() < 0.5 ? '🪙 **Heads!**' : '🪙 **Tails!**';
        await interaction.reply(result);
    }
};
