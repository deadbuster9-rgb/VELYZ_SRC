import { SlashCommandBuilder } from 'discord.js';
export const data = {
    data: new SlashCommandBuilder().setName('pp').setDescription('Measure the pp size 🍆')
        .addUserOption(o => o.setName('user').setDescription('User to measure')),
    category: 'fun',
    async execute(interaction) {
        const user = interaction.options.getUser('user') || interaction.user;
        const size = Math.floor(Math.random() * 15);
        const pp = `8${'='.repeat(size)}D`;
        const msg =
            size >= 12 ? '😱 Absolutely massive. Call a doctor.' :
            size >= 9  ? '😳 Big energy detected.' :
            size >= 6  ? '🙂 Decent. No complaints.' :
            size >= 3  ? '😬 It\'s the motion of the ocean, bro.' :
            '🔬 Microscope needed.';
        await interaction.reply(`**PP size for ${user}**\n\`\`\`\n${pp}\n\`\`\`${msg}`);
    }
};
