import { SlashCommandBuilder } from 'discord.js';
export const data = {
    data: new SlashCommandBuilder().setName('ship').setDescription('Ship two people together 💞')
        .addUserOption(o => o.setName('user1').setDescription('First user').setRequired(true))
        .addUserOption(o => o.setName('user2').setDescription('Second user').setRequired(true)),
    category: 'fun',
    async execute(interaction) {
        const u1 = interaction.options.getUser('user1');
        const u2 = interaction.options.getUser('user2');
        const pct = Math.floor(Math.random() * 101);
        const hearts = '❤️'.repeat(Math.ceil(pct/20)) || '💔';
        const bar = '█'.repeat(Math.floor(pct/10)) + '░'.repeat(10 - Math.floor(pct/10));
        const msg =
            pct >= 90 ? '💍 Perfect match. Get married already.' :
            pct >= 70 ? '💕 Strong connection. Very cute.' :
            pct >= 50 ? '😊 It could work with some effort!' :
            pct >= 30 ? '😬 It\'s giving situationship energy.' :
            '💔 Absolutely not. Zero chemistry.';
        await interaction.reply(`**${u1.username} ❤️ ${u2.username}**\n\`\`\`\n[${bar}] ${pct}%\n\`\`\`${hearts}\n${msg}`);
    }
};
