import { SlashCommandBuilder } from 'discord.js';
export const data = {
    data: new SlashCommandBuilder().setName('iq').setDescription('Check someone\'s IQ 🧠')
        .addUserOption(o => o.setName('user').setDescription('User to check')),
    category: 'fun',
    async execute(interaction) {
        const user = interaction.options.getUser('user') || interaction.user;
        const iq = Math.floor(Math.random() * 200) + 1;
        const msg =
            iq >= 160 ? '🧠 Genius level. Probably solving quantum physics for fun.' :
            iq >= 130 ? '📚 Very smart. Definitely cheats on exams.' :
            iq >= 110 ? '💡 Above average. Reads Wikipedia for fun.' :
            iq >= 90  ? '🙂 Average. Google is their best friend.' :
            iq >= 70  ? '😬 A bit below average. Uses calculator for 2+2.' :
            '🪨 Rock-level IQ. Probably clicked "I agree" without reading.';
        await interaction.reply(`**IQ test result for ${user}**\n\`\`\`\nIQ Score: ${iq}\n\`\`\`${msg}`);
    }
};
