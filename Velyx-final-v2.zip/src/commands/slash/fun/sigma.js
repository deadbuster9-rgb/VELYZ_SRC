import { SlashCommandBuilder } from 'discord.js';
export const data = {
    data: new SlashCommandBuilder().setName('sigma').setDescription('Check the sigma grindset level 😤')
        .addUserOption(o => o.setName('user').setDescription('User to check')),
    category: 'fun',
    async execute(interaction) {
        const user = interaction.options.getUser('user') || interaction.user;
        const pct = Math.floor(Math.random() * 101);
        const bar = '█'.repeat(Math.floor(pct/10)) + '░'.repeat(10 - Math.floor(pct/10));
        const msg =
            pct >= 95 ? '😤 Lone wolf. No friends. Pure grindset. Sigma male detected.' :
            pct >= 80 ? '💪 Very sigma. Hustle never stops.' :
            pct >= 60 ? '🔥 Sigma energy present. Keep grinding.' :
            pct >= 40 ? '📈 Some sigma potential. Needs more gym.' :
            pct >= 20 ? '😐 More beta than sigma rn.' :
            '🥀 Full beta. Touch grass and hit the gym.';
        await interaction.reply(`**Sigma grindset meter for ${user}**\n\`\`\`\n[${bar}] ${pct}%\n\`\`\`${msg}`);
    }
};
