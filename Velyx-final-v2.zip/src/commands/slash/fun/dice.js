import { SlashCommandBuilder } from 'discord.js';
export const data = {
    data: new SlashCommandBuilder().setName('dice').setDescription('Roll a dice 🎲')
        .addIntegerOption(o => o.setName('sides').setDescription('Number of sides (default 6)').setMinValue(2).setMaxValue(100)),
    category: 'fun',
    async execute(interaction) {
        const sides = interaction.options.getInteger('sides') || 6;
        const roll = Math.floor(Math.random() * sides) + 1;
        await interaction.reply(`🎲 Rolled a **${sides}**-sided dice: **${roll}**`);
    }
};
