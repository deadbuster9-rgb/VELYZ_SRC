import {
    SlashCommandBuilder, EmbedBuilder, ActionRowBuilder,
    ButtonBuilder, ButtonStyle, ChannelType, PermissionFlagsBits,
    StringSelectMenuBuilder, MessageFlags
} from 'discord.js';
import emojis from '../../../config/emojis.js';

export const data = {
    data: new SlashCommandBuilder()
        .setName('ticket')
        .setDescription('Ticket system management')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
        .addSubcommand(s => s.setName('setup')
            .setDescription('Setup the ticket system')
            .addChannelOption(o => o.setName('category').setDescription('Category for tickets').setRequired(true))
            .addRoleOption(o => o.setName('support_role').setDescription('Support team role').setRequired(true))
            .addRoleOption(o => o.setName('admin_role').setDescription('Admin role').setRequired(true))
            .addChannelOption(o => o.setName('log_channel').setDescription('Ticket log channel').setRequired(true))
            .addChannelOption(o => o.setName('transcript_channel').setDescription('Transcript channel').setRequired(true))
        )
        .addSubcommand(s => s.setName('panel')
            .setDescription('Send the ticket panel to a channel')
            .addChannelOption(o => o.setName('channel').setDescription('Channel to send panel').setRequired(true))
        )
        .addSubcommand(s => s.setName('add')
            .setDescription('Add a user to the current ticket')
            .addUserOption(o => o.setName('user').setDescription('User to add').setRequired(true))
        )
        .addSubcommand(s => s.setName('remove')
            .setDescription('Remove a user from the current ticket')
            .addUserOption(o => o.setName('user').setDescription('User to remove').setRequired(true))
        )
        .addSubcommand(s => s.setName('close')
            .setDescription('Close the current ticket')
            .addStringOption(o => o.setName('reason').setDescription('Reason for closing'))
        )
        .addSubcommand(s => s.setName('rename')
            .setDescription('Rename the current ticket')
            .addStringOption(o => o.setName('name').setDescription('New ticket name').setRequired(true))
        )
        .addSubcommand(s => s.setName('settings')
            .setDescription('View ticket system settings')
        ),

    async execute(interaction, client) {
        const sub = interaction.options.getSubcommand();
        const db = client.ticketDB;

        // ── SETUP ──
        if (sub === 'setup') {
            const category = interaction.options.getChannel('category');
            const supportRole = interaction.options.getRole('support_role');
            const adminRole = interaction.options.getRole('admin_role');
            const logChannel = interaction.options.getChannel('log_channel');
            const transcriptChannel = interaction.options.getChannel('transcript_channel');

            if (category.type !== ChannelType.GuildCategory) {
                return interaction.reply({ content: `${emojis.cross} Please select a **Category** channel, not a text channel.`, flags: MessageFlags.Ephemeral });
            }

            await db.set(`ticket_config_${interaction.guild.id}`, {
                categoryId: category.id,
                supportRoleId: supportRole.id,
                adminRoleId: adminRole.id,
                logChannelId: logChannel.id,
                transcriptChannelId: transcriptChannel.id,
                ticketCount: 0,
                enabled: true
            });

            const embed = new EmbedBuilder()
                .setColor(client.color)
                .setTitle('🎫 Ticket System Setup Complete')
                .addFields(
                    { name: '📁 Category', value: `${category}`, inline: true },
                    { name: '🛡️ Support Role', value: `${supportRole}`, inline: true },
                    { name: '👑 Admin Role', value: `${adminRole}`, inline: true },
                    { name: '📋 Log Channel', value: `${logChannel}`, inline: true },
                    { name: '📄 Transcript Channel', value: `${transcriptChannel}`, inline: true },
                )
                .setFooter({ text: `Setup by ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL() })
                .setTimestamp();

            return interaction.reply({ embeds: [embed] });
        }

        // ── PANEL ──
        if (sub === 'panel') {
            const config = await db.get(`ticket_config_${interaction.guild.id}`);
            if (!config) return interaction.reply({ content: `${emojis.cross} Run \`/ticket setup\` first.`, flags: MessageFlags.Ephemeral });

            const channel = interaction.options.getChannel('channel');

            const panelEmbed = new EmbedBuilder()
                .setColor(client.color)
                .setTitle('🎫 Support Tickets')
                .setDescription(
                    `Need help? Open a ticket using the menu below.\n\n` +
                    `📌 **Categories:**\n` +
                    `> 🆘 **General Support** — General questions & help\n` +
                    `> 🐛 **Bug Report** — Report bugs or issues\n` +
                    `> 💡 **Suggestions** — Share your ideas\n` +
                    `> 💎 **Premium Support** — Premium user assistance\n` +
                    `> ⚖️ **Appeals** — Ban/mute appeals\n\n` +
                    `*Please do not abuse the ticket system.*`
                )
                .setThumbnail(interaction.guild.iconURL({ size: 1024 }))
                .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() })
                .setTimestamp();

            const selectMenu = new StringSelectMenuBuilder()
                .setCustomId('ticket_create')
                .setPlaceholder('📂 Select a ticket category...')
                .addOptions([
                    { label: 'General Support', description: 'Get help with general questions', value: 'general', emoji: '🆘' },
                    { label: 'Bug Report', description: 'Report a bug or issue', value: 'bug', emoji: '🐛' },
                    { label: 'Suggestion', description: 'Share an idea or suggestion', value: 'suggestion', emoji: '💡' },
                    { label: 'Premium Support', description: 'Support for premium users', value: 'premium', emoji: '💎' },
                    { label: 'Appeal', description: 'Appeal a ban or mute', value: 'appeal', emoji: '⚖️' },
                ]);

            const row = new ActionRowBuilder().addComponents(selectMenu);

            await channel.send({ embeds: [panelEmbed], components: [row] });
            return interaction.reply({ content: `${emojis.tick} Ticket panel sent to ${channel}!`, flags: MessageFlags.Ephemeral });
        }

        // ── ADD USER ──
        if (sub === 'add') {
            const ticketData = await db.get(`ticket_channel_${interaction.channel.id}`);
            if (!ticketData) return interaction.reply({ content: `${emojis.cross} This is not a ticket channel.`, flags: MessageFlags.Ephemeral });

            const user = interaction.options.getUser('user');
            await interaction.channel.permissionOverwrites.edit(user.id, { ViewChannel: true, SendMessages: true, ReadMessageHistory: true });

            const embed = new EmbedBuilder()
                .setColor(client.color)
                .setDescription(`${emojis.tick} **${user}** has been added to the ticket.`);

            return interaction.reply({ embeds: [embed] });
        }

        // ── REMOVE USER ──
        if (sub === 'remove') {
            const ticketData = await db.get(`ticket_channel_${interaction.channel.id}`);
            if (!ticketData) return interaction.reply({ content: `${emojis.cross} This is not a ticket channel.`, flags: MessageFlags.Ephemeral });

            const user = interaction.options.getUser('user');
            if (user.id === ticketData.userId) return interaction.reply({ content: `${emojis.cross} You cannot remove the ticket owner.`, flags: MessageFlags.Ephemeral });

            await interaction.channel.permissionOverwrites.delete(user.id);
            const embed = new EmbedBuilder()
                .setColor(client.color)
                .setDescription(`${emojis.tick} **${user}** has been removed from the ticket.`);

            return interaction.reply({ embeds: [embed] });
        }

        // ── CLOSE ──
        if (sub === 'close') {
            const ticketData = await db.get(`ticket_channel_${interaction.channel.id}`);
            if (!ticketData) return interaction.reply({ content: `${emojis.cross} This is not a ticket channel.`, flags: MessageFlags.Ephemeral });

            const reason = interaction.options.getString('reason') || 'No reason provided';
            await closeTicket(interaction.channel, interaction.user, reason, client, db);
            return;
        }

        // ── RENAME ──
        if (sub === 'rename') {
            const ticketData = await db.get(`ticket_channel_${interaction.channel.id}`);
            if (!ticketData) return interaction.reply({ content: `${emojis.cross} This is not a ticket channel.`, flags: MessageFlags.Ephemeral });

            const name = interaction.options.getString('name').toLowerCase().replace(/\s+/g, '-');
            await interaction.channel.setName(name);
            const embed = new EmbedBuilder().setColor(client.color)
                .setDescription(`${emojis.tick} Ticket renamed to **${name}**`);
            return interaction.reply({ embeds: [embed] });
        }

        // ── SETTINGS ──
        if (sub === 'settings') {
            const config = await db.get(`ticket_config_${interaction.guild.id}`);
            if (!config) return interaction.reply({ content: `${emojis.cross} Ticket system not configured. Run \`/ticket setup\` first.`, flags: MessageFlags.Ephemeral });

            const embed = new EmbedBuilder()
                .setColor(client.color)
                .setTitle('🎫 Ticket System Settings')
                .addFields(
                    { name: '📁 Category', value: `<#${config.categoryId}>`, inline: true },
                    { name: '🛡️ Support Role', value: `<@&${config.supportRoleId}>`, inline: true },
                    { name: '👑 Admin Role', value: `<@&${config.adminRoleId}>`, inline: true },
                    { name: '📋 Log Channel', value: `<#${config.logChannelId}>`, inline: true },
                    { name: '📄 Transcript Channel', value: `<#${config.transcriptChannelId}>`, inline: true },
                    { name: '🎟️ Total Tickets', value: `${config.ticketCount || 0}`, inline: true },
                )
                .setTimestamp();
            return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
        }
    }
};

export async function closeTicket(channel, closedBy, reason, client, db) {
    const ticketData = await db.get(`ticket_channel_${channel.id}`);
    if (!ticketData) return;

    const config = await db.get(`ticket_config_${channel.guild.id}`);

    // Generate transcript
    const messages = await channel.messages.fetch({ limit: 100 });
    const transcript = messages.reverse().map(m =>
        `[${new Date(m.createdTimestamp).toLocaleString()}] ${m.author.username}: ${m.content || '[embed/attachment]'}`
    ).join('\n');

    const transcriptBuf = Buffer.from(transcript, 'utf-8');

    // Send to transcript channel
    if (config?.transcriptChannelId) {
        const transcriptCh = channel.guild.channels.cache.get(config.transcriptChannelId);
        if (transcriptCh) {
            const transcriptEmbed = new EmbedBuilder()
                .setColor(0x5865F2)
                .setTitle(`📄 Ticket Transcript — #${channel.name}`)
                .addFields(
                    { name: '🎫 Ticket', value: channel.name, inline: true },
                    { name: '👤 Opened By', value: `<@${ticketData.userId}>`, inline: true },
                    { name: '🔒 Closed By', value: `${closedBy}`, inline: true },
                    { name: '📋 Reason', value: reason, inline: false },
                )
                .setTimestamp();
            await transcriptCh.send({
                embeds: [transcriptEmbed],
                files: [{ attachment: transcriptBuf, name: `transcript-${channel.name}.txt` }]
            }).catch(() => {});
        }
    }

    // Send to log channel
    if (config?.logChannelId) {
        const logCh = channel.guild.channels.cache.get(config.logChannelId);
        if (logCh) {
            const logEmbed = new EmbedBuilder()
                .setColor(0xED4245)
                .setTitle('🔒 Ticket Closed')
                .addFields(
                    { name: '🎫 Ticket', value: channel.name, inline: true },
                    { name: '👤 Opened By', value: `<@${ticketData.userId}>`, inline: true },
                    { name: '🔒 Closed By', value: `${closedBy}`, inline: true },
                    { name: '📋 Reason', value: reason },
                )
                .setTimestamp();
            await logCh.send({ embeds: [logEmbed] }).catch(() => {});
        }
    }

    await db.delete(`ticket_channel_${channel.id}`);
    await channel.delete(`Ticket closed by ${closedBy.username} — ${reason}`).catch(() => {});
}
