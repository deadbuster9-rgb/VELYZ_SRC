import { ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder, SlashCommandBuilder } from 'discord.js';
import config from '../../../config/config.js';

export const data = {
    data: new SlashCommandBuilder()
        .setName('support')
        .setDescription('Get the Velyx support server link.'),
    async execute(interaction, client) {
        const embed = new EmbedBuilder()
            .setColor(client.color)
            .setAuthor({ name: `${client.user.username} Support`, iconURL: client.user.displayAvatarURL({ dynamic: true }) })
            .setDescription(`Need help? Join our support server!`)
            .setFooter({ text: `Requested by ${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) });

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setLabel('Support Server').setStyle(ButtonStyle.Link).setURL(config.links.supportServer)
        );

        await interaction.reply({ embeds: [embed], components: [row] });
    }
};
