import { SlashCommandBuilder } from 'discord.js';
import pkg from '@napi-rs/canvas';
const { createCanvas, loadImage } = pkg;
import emojis from '../../../config/emojis.js';

function fmt(ms){ const s=Math.floor(ms/1000); return `${Math.floor(s/60)}:${(s%60).toString().padStart(2,'0')}`; }

async function drawQueue(tracks, total, current) {
    const W=600, HH=70, IH=58;
    const H = HH + tracks.length * IH;
    const canvas = createCanvas(W, H);
    const ctx = canvas.getContext('2d');

    ctx.fillStyle='#0A0A0A'; ctx.fillRect(0,0,W,H);
    const g=ctx.createLinearGradient(0,0,W,H);
    g.addColorStop(0,'rgba(30,30,30,0.5)'); g.addColorStop(1,'rgba(10,10,10,0.8)');
    ctx.fillStyle=g; ctx.fillRect(0,0,W,H);

    const cr=25; ctx.save();
    ctx.beginPath();
    ctx.moveTo(cr,0);ctx.lineTo(W-cr,0);ctx.quadraticCurveTo(W,0,W,cr);
    ctx.lineTo(W,H-cr);ctx.quadraticCurveTo(W,H,W-cr,H);
    ctx.lineTo(cr,H);ctx.quadraticCurveTo(0,H,0,H-cr);
    ctx.lineTo(0,cr);ctx.quadraticCurveTo(0,0,cr,0);
    ctx.closePath(); ctx.clip();

    ctx.strokeStyle='rgba(255,255,255,0.05)'; ctx.lineWidth=1;
    ctx.beginPath(); ctx.roundRect(5,5,W-10,H-10,24); ctx.stroke();

    // Header
    ctx.font='bold 26px sans-serif'; ctx.fillStyle='#fff';
    ctx.textBaseline='middle'; ctx.shadowColor='rgba(0,0,0,0.4)'; ctx.shadowBlur=3;
    ctx.fillText('Music Queue', 22, HH/2);
    ctx.textAlign='right'; ctx.font='15px sans-serif'; ctx.fillStyle='#999';
    ctx.fillText(`${total} tracks`, W-20, HH/2);
    ctx.textAlign='left'; ctx.shadowColor='transparent'; ctx.shadowBlur=0;

    // Divider
    ctx.strokeStyle='rgba(255,255,255,0.08)'; ctx.lineWidth=1;
    ctx.beginPath(); ctx.moveTo(15,HH-1); ctx.lineTo(W-15,HH-1); ctx.stroke();

    for (let i=0; i<tracks.length; i++) {
        const t = tracks[i];
        const y = HH + i*IH;

        // Row bg
        if (i%2===0) { ctx.fillStyle='rgba(255,255,255,0.025)'; ctx.fillRect(0,y,W,IH); }

        // Badge
        const bx=28, by=y+IH/2;
        ctx.fillStyle='rgba(60,60,60,0.6)';
        ctx.beginPath(); ctx.arc(bx,by,13,0,Math.PI*2); ctx.fill();
        ctx.font='bold 13px sans-serif'; ctx.fillStyle='#fff';
        ctx.textAlign='center'; ctx.textBaseline='middle';
        ctx.fillText((i+1).toString(), bx, by);
        ctx.textAlign='left';

        // Thumbnail
        const TS=38, TX=52, TY=y+IH/2-TS/2;
        let thumb=null; try{ thumb=await loadImage(t.info.thumbnail); }catch(_){}
        if(thumb){
            ctx.save(); ctx.beginPath(); ctx.roundRect(TX,TY,TS,TS,5); ctx.clip();
            ctx.drawImage(thumb,TX,TY,TS,TS); ctx.restore();
        } else { ctx.fillStyle='#333'; ctx.fillRect(TX,TY,TS,TS); }

        // Text
        const textX = TX+TS+12;
        const maxW = W-textX-90;
        ctx.shadowColor='rgba(0,0,0,0.4)'; ctx.shadowBlur=2;

        // Is this current?
        const isCurrent = current && t.track === current.track;
        ctx.font='bold 16px sans-serif';
        ctx.fillStyle = isCurrent ? '#4ade80' : '#fff';

        let title=t.info.title;
        while(ctx.measureText(title+'…').width>maxW && title.length>1) title=title.slice(0,-1);
        if(title!==t.info.title) title+='…';
        ctx.fillText(title, textX, y+20);

        ctx.font='13px sans-serif'; ctx.fillStyle='#999'; ctx.shadowBlur=0;
        ctx.fillText(t.info.author, textX, y+38);

        // Duration
        if(t.info.length){
            ctx.font='13px sans-serif'; ctx.fillStyle='#777';
            ctx.textAlign='right'; ctx.fillText(fmt(t.info.length), W-18, y+IH/2);
            ctx.textAlign='left';
        }
    }
    ctx.shadowColor='transparent';
    return canvas.toBuffer('image/png');
}

export const data = {
    data: new SlashCommandBuilder()
        .setName('queue')
        .setDescription('Show the current music queue')
        .addIntegerOption(o => o.setName('page').setDescription('Page number').setMinValue(1)),
    category: 'music',

    async execute(interaction, client) {
        const player = client.riffy.players.get(interaction.guildId);
        if (!player || !player.queue.length)
            return interaction.reply({ content: `${emojis.warn} The queue is empty.`, ephemeral: true });

        await interaction.deferReply();
        try {
            const page = (interaction.options.getInteger('page') || 1) - 1;
            const perPage = 10;
            const all = [...player.queue];
            const slice = all.slice(page*perPage, (page+1)*perPage);
            const buf = await drawQueue(slice, player.queue.length, player.current);
            await interaction.editReply({ files: [{ attachment: buf, name: 'queue.png' }] });
        } catch(err) {
            console.error(err);
            interaction.editReply(`${emojis.cross} ${err.message}`).catch(()=>{});
        }
    }
};
