import { SlashCommandBuilder } from 'discord.js';
import emojis from '../../../config/emojis.js';
export const data = {
    data: new SlashCommandBuilder().setName('volume').setDescription('Set or check the volume')
        .addIntegerOption(o => o.setName('level').setDescription('Volume 0–100').setMinValue(0).setMaxValue(100)),
    category: 'music',
    async execute(interaction, client) {
        const p = client.riffy.players.get(interaction.guildId);
        if (!p) return interaction.reply({ content: `${emojis.warn} No active session.`, ephemeral: true });
        const lvl = interaction.options.getInteger('level');
        if (lvl === null) return interaction.reply(`🔊 Current volume: **${p.volume}%**`);
        p.setVolume(lvl);
        const icon = lvl===0?'🔇':lvl<=30?'🔈':lvl<=70?'🔉':'🔊';
        await interaction.reply(`${icon} Volume set to **${lvl}%**`);
    }
};
