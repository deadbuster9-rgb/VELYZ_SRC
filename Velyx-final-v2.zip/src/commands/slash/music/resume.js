import { SlashCommandBuilder } from 'discord.js';
import emojis from '../../../config/emojis.js';
export const data = {
    data: new SlashCommandBuilder().setName('resume').setDescription('Resume the paused track'),
    category: 'music',
    async execute(interaction, client) {
        const p = client.riffy.players.get(interaction.guildId);
        if (!p) return interaction.reply({ content: `${emojis.warn} No active session.`, ephemeral: true });
        if (!p.paused) return interaction.reply({ content: `${emojis.warn} Not paused.`, ephemeral: true });
        p.pause(false);
        await interaction.reply(`▶️ Resumed the track.`);
    }
};
