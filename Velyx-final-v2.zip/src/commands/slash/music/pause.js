import { SlashCommandBuilder } from 'discord.js';
import emojis from '../../../config/emojis.js';
export const data = {
    data: new SlashCommandBuilder().setName('pause').setDescription('Pause the current track'),
    category: 'music',
    async execute(interaction, client) {
        const p = client.riffy.players.get(interaction.guildId);
        if (!p?.playing) return interaction.reply({ content: `${emojis.warn} Nothing is playing.`, ephemeral: true });
        if (p.paused) return interaction.reply({ content: `${emojis.warn} Already paused.`, ephemeral: true });
        p.pause(true);
        await interaction.reply(`⏸️ Paused the track.`);
    }
};
