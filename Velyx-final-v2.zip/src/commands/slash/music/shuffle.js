import { SlashCommandBuilder } from 'discord.js';
import emojis from '../../../config/emojis.js';
export const data = {
    data: new SlashCommandBuilder().setName('shuffle').setDescription('Shuffle the queue'),
    category: 'music',
    async execute(interaction, client) {
        const p = client.riffy.players.get(interaction.guildId);
        if (!p || p.queue.length < 2)
            return interaction.reply({ content: `${emojis.warn} Need at least 2 tracks to shuffle.`, ephemeral: true });
        p.queue.shuffle();
        await interaction.reply(`🔀 Queue shuffled! (${p.queue.length} tracks)`);
    }
};
