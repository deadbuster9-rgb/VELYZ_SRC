import { SlashCommandBuilder } from 'discord.js';
import emojis from '../../../config/emojis.js';
export const data = {
    data: new SlashCommandBuilder().setName('seek').setDescription('Seek to a position in the track')
        .addStringOption(o => o.setName('position').setDescription('Time e.g. 1:30').setRequired(true)),
    category: 'music',
    async execute(interaction, client) {
        const p = client.riffy.players.get(interaction.guildId);
        if (!p?.playing) return interaction.reply({ content: `${emojis.warn} Nothing is playing.`, ephemeral: true });
        const pos = interaction.options.getString('position');
        const match = pos.match(/^(\d{1,2}):([0-5]\d)$/);
        if (!match) return interaction.reply({ content: `${emojis.warn} Use format \`m:ss\` (e.g. \`1:30\`).`, ephemeral: true });
        const ms = (parseInt(match[1])*60 + parseInt(match[2])) * 1000;
        p.seek(ms);
        await interaction.reply(`⏩ Seeked to **${pos}**`);
    }
};
