import { SlashCommandBuilder } from 'discord.js';
import pkg from '@napi-rs/canvas';
const { createCanvas, loadImage } = pkg;
import emojis from '../../../config/emojis.js';

function formatDuration(ms) {
    const s = Math.floor(ms / 1000);
    return `${Math.floor(s / 60)}:${(s % 60).toString().padStart(2, '0')}`;
}

// Wait until player connection is ready
function waitForConnection(player, ms = 5000) {
    return new Promise((resolve, reject) => {
        const start = Date.now();
        const check = setInterval(() => {
            if (player.connected) {
                clearInterval(check);
                return resolve();
            }
            if (Date.now() - start > ms) {
                clearInterval(check);
                return reject(new Error('Voice connection timed out.'));
            }
        }, 100);
    });
}

async function drawCard(track, queuePos) {
    const W = 600, H = 150;
    const canvas = createCanvas(W, H);
    const ctx = canvas.getContext('2d');

    ctx.fillStyle = '#0A0A0A';
    ctx.fillRect(0, 0, W, H);
    const grad = ctx.createLinearGradient(0, 0, W, H);
    grad.addColorStop(0, 'rgba(30,30,30,0.5)');
    grad.addColorStop(1, 'rgba(10,10,10,0.8)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, W, H);

    const r = 25;
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(r,0); ctx.lineTo(W-r,0); ctx.quadraticCurveTo(W,0,W,r);
    ctx.lineTo(W,H-r); ctx.quadraticCurveTo(W,H,W-r,H);
    ctx.lineTo(r,H); ctx.quadraticCurveTo(0,H,0,H-r);
    ctx.lineTo(0,r); ctx.quadraticCurveTo(0,0,r,0);
    ctx.closePath(); ctx.clip();

    ctx.strokeStyle = 'rgba(255,255,255,0.05)'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.roundRect(5,5,W-10,H-10,24); ctx.stroke();

    const IS = 120, IX = 15, IY = 15;
    let art = null;
    try { art = await loadImage(track.info.thumbnail); } catch (_) {}

    if (art) {
        const bg = createCanvas(W, H); const bgCtx = bg.getContext('2d');
        const ar = art.width / art.height;
        let bw = W, bh = W / ar;
        if (bh < H) { bh = H; bw = H * ar; }
        bgCtx.drawImage(art, (W-bw)/2, (H-bh)/2, bw, bh);
        bgCtx.globalAlpha = 0.3;
        for (let i = -2; i <= 2; i++) for (let j = -2; j <= 2; j++)
            bgCtx.drawImage(bg, i, j, W, H);
        ctx.globalAlpha = 0.18; ctx.drawImage(bg, 0, 0, W, H); ctx.globalAlpha = 1;

        ctx.save();
        ctx.beginPath(); ctx.roundRect(IX, IY, IS, IS, 12); ctx.clip();
        ctx.drawImage(art, IX, IY, IS, IS);
        ctx.restore();
    } else {
        ctx.fillStyle = '#222'; ctx.fillRect(IX, IY, IS, IS);
    }

    const bx = W - 35, by = H / 2;
    ctx.fillStyle = '#e0e0e0';
    ctx.beginPath(); ctx.arc(bx, by, 20, 0, Math.PI*2); ctx.fill();
    ctx.fillStyle = '#101010'; ctx.font = 'bold 18px sans-serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(queuePos.toString(), bx, by);
    ctx.textAlign = 'left';

    const TX = IX + IS + 18;
    const maxW = W - TX - 60;
    ctx.fillStyle = '#fff'; ctx.shadowColor = 'rgba(0,0,0,0.5)';
    ctx.shadowBlur = 4; ctx.shadowOffsetX = 1; ctx.shadowOffsetY = 1;
    ctx.font = 'bold 28px sans-serif'; ctx.textBaseline = 'alphabetic';

    let title = track.info.title;
    while (ctx.measureText(title + '…').width > maxW && title.length > 1) title = title.slice(0,-1);
    if (title !== track.info.title) title += '…';
    ctx.fillText(title, TX, IY + 45);

    ctx.font = '20px sans-serif'; ctx.fillStyle = '#bbb';
    ctx.fillText(track.info.author, TX, IY + 74);

    ctx.font = '16px sans-serif'; ctx.fillStyle = '#888';
    ctx.fillText(formatDuration(track.info.length), TX, IY + 100);

    ctx.shadowColor = 'transparent'; ctx.shadowBlur = 0;
    return canvas.toBuffer('image/png');
}

export const data = {
    data: new SlashCommandBuilder()
        .setName('play')
        .setDescription('Play a song from YouTube, Spotify or SoundCloud')
        .addStringOption(o => o.setName('query').setDescription('Song name or URL').setRequired(true)),
    category: 'music',

    async execute(interaction, client) {
        const query = interaction.options.getString('query');
        const vc = interaction.member.voice.channel;

        if (!vc) return interaction.reply({ content: `${emojis.warn} You need to be in a voice channel first!`, ephemeral: true });

        await interaction.deferReply();

        try {
            const player = client.riffy.createConnection({
                guildId: interaction.guildId,
                voiceChannel: vc.id,
                textChannel: interaction.channelId,
                deaf: true,
            });

            const resolve = await client.riffy.resolve({ query, requester: interaction.user });
            const { loadType, tracks, playlistInfo } = resolve;

            if (!tracks?.length) return interaction.editReply(`${emojis.cross} No results found for **${query}**`);

            if (loadType === 'playlist') {
                for (const t of tracks) { t.info.requester = interaction.user; player.queue.add(t); }
                if (!player.playing && !player.paused) {
                    await waitForConnection(player).catch(() => {});
                    player.play().catch(() => {});
                }
                return interaction.editReply(`${emojis.tick} Added **${tracks.length}** tracks from playlist \`${playlistInfo.name}\` to the queue.`);
            }

            const track = tracks[0];
            track.info.requester = interaction.user;
            player.queue.add(track);

            if (!player.playing && !player.paused) {
                await waitForConnection(player).catch(() => {});
                player.play().catch(() => {});
            }

            const pos = player.queue.size;
            const buf = await drawCard(track, pos);
            await interaction.editReply({ files: [{ attachment: buf, name: 'play.png' }] });

        } catch (err) {
            console.error(err);
            interaction.editReply(`${emojis.cross} Error: ${err.message}`).catch(() => {});
        }
    }
};
