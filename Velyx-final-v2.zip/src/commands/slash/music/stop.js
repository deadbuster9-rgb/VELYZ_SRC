import { SlashCommandBuilder } from 'discord.js';
import emojis from '../../../config/emojis.js';
export const data = {
    data: new SlashCommandBuilder().setName('stop').setDescription('Stop music and leave the voice channel'),
    category: 'music',
    async execute(interaction, client) {
        const p = client.riffy.players.get(interaction.guildId);
        if (!p) return interaction.reply({ content: `${emojis.warn} No active music session.`, ephemeral: true });
        p.destroy();
        await interaction.reply(`${emojis.tick} Stopped the music and left the channel.`);
    }
};
