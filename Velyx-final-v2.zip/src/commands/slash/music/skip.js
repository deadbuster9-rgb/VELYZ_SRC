import { SlashCommandBuilder } from 'discord.js';
import emojis from '../../../config/emojis.js';
export const data = {
    data: new SlashCommandBuilder().setName('skip').setDescription('Skip the current track'),
    category: 'music',
    async execute(interaction, client) {
        const p = client.riffy.players.get(interaction.guildId);
        if (!p?.playing) return interaction.reply({ content: `${emojis.warn} Nothing is playing.`, ephemeral: true });
        p.stop();
        await interaction.reply(`${emojis.tick} Skipped the current track.`);
    }
};
