import { SlashCommandBuilder } from 'discord.js';
import emojis from '../../../config/emojis.js';
export const data = {
    data: new SlashCommandBuilder().setName('loop').setDescription('Set loop mode')
        .addStringOption(o => o.setName('mode').setDescription('Loop mode').setRequired(true)
            .addChoices({name:'Off',value:'none'},{name:'Track',value:'track'},{name:'Queue',value:'queue'})),
    category: 'music',
    async execute(interaction, client) {
        const p = client.riffy.players.get(interaction.guildId);
        if (!p?.playing) return interaction.reply({ content: `${emojis.warn} Nothing is playing.`, ephemeral: true });
        const mode = interaction.options.getString('mode');
        p.setLoop(mode);
        const labels = { none:'🔄 Loop **disabled**', track:'🔂 Looping **current track**', queue:'🔁 Looping **queue**' };
        await interaction.reply(labels[mode]);
    }
};
