import { SlashCommandBuilder } from 'discord.js';
import pkg from '@napi-rs/canvas';
const { createCanvas, loadImage } = pkg;
import emojis from '../../../config/emojis.js';

function fmt(ms) {
    const s = Math.floor(ms/1000);
    return `${Math.floor(s/60)}:${(s%60).toString().padStart(2,'0')}`;
}

async function drawNP(track, position) {
    const W = 600, H = 145;
    const canvas = createCanvas(W, H);
    const ctx = canvas.getContext('2d');

    ctx.fillStyle = '#0A0A0A'; ctx.fillRect(0,0,W,H);
    const g = ctx.createLinearGradient(0,0,W,H);
    g.addColorStop(0,'rgba(30,30,30,0.5)'); g.addColorStop(1,'rgba(10,10,10,0.8)');
    ctx.fillStyle = g; ctx.fillRect(0,0,W,H);

    const cr = 25;
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(cr,0); ctx.lineTo(W-cr,0); ctx.quadraticCurveTo(W,0,W,cr);
    ctx.lineTo(W,H-cr); ctx.quadraticCurveTo(W,H,W-cr,H);
    ctx.lineTo(cr,H); ctx.quadraticCurveTo(0,H,0,H-cr);
    ctx.lineTo(0,cr); ctx.quadraticCurveTo(0,0,cr,0);
    ctx.closePath(); ctx.clip();

    ctx.strokeStyle = 'rgba(255,255,255,0.05)'; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.roundRect(5,5,W-10,H-10,24); ctx.stroke();

    const IS = 105, IX = 15, IY = 15;
    let art = null;
    try { art = await loadImage(track.info.thumbnail); } catch(_) {}

    if (art) {
        const bg = createCanvas(W,H); const bgCtx = bg.getContext('2d');
        const ar = art.width/art.height; let bw=W, bh=W/ar;
        if (bh<H){bh=H;bw=H*ar;}
        bgCtx.drawImage(art,(W-bw)/2,(H-bh)/2,bw,bh);
        bgCtx.globalAlpha=0.3;
        for(let i=-2;i<=2;i++) for(let j=-2;j<=2;j++) bgCtx.drawImage(bg,i,j,W,H);
        ctx.globalAlpha=0.18; ctx.drawImage(bg,0,0,W,H); ctx.globalAlpha=1;

        ctx.save(); ctx.beginPath(); ctx.roundRect(IX,IY,IS,IS,12); ctx.clip();
        ctx.drawImage(art,IX,IY,IS,IS); ctx.restore();
    } else {
        ctx.fillStyle='#222'; ctx.fillRect(IX,IY,IS,IS);
    }

    const TX = IX + IS + 18;
    const maxW = W - TX - 20;
    const dur = track.info.length || 0;
    const prog = dur > 0 ? position/dur : 0;

    // Title
    ctx.fillStyle='#fff'; ctx.shadowColor='rgba(0,0,0,0.5)';
    ctx.shadowBlur=4; ctx.font='bold 32px sans-serif'; ctx.textBaseline='alphabetic';
    let title = track.info.title;
    while(ctx.measureText(title+'…').width > maxW && title.length > 1) title=title.slice(0,-1);
    if(title !== track.info.title) title += '…';
    ctx.fillText(title, TX, IY+38);

    // NOW PLAYING label
    ctx.font='13px sans-serif'; ctx.fillStyle='#888';
    ctx.shadowBlur=0; ctx.fillText('NOW PLAYING', TX, IY+60);

    // Author
    ctx.font='18px sans-serif'; ctx.fillStyle='#ccc';
    ctx.fillText(track.info.author, TX, IY+82);

    // Progress bar
    const PX = TX, PY = H - 30, PW = W - TX - 20, PH = 4;
    ctx.fillStyle='rgba(255,255,255,0.12)';
    ctx.beginPath(); ctx.roundRect(PX,PY,PW,PH,2); ctx.fill();
    ctx.fillStyle='#fff';
    const pw = Math.max(0, Math.min(prog*PW, PW));
    ctx.beginPath(); ctx.roundRect(PX,PY,pw,PH,2); ctx.fill();
    // Dot
    ctx.beginPath(); ctx.arc(PX+pw, PY+PH/2, 5, 0, Math.PI*2); ctx.fill();

    // Times
    ctx.font='13px sans-serif'; ctx.fillStyle='#aaa';
    ctx.textAlign='left';  ctx.fillText(fmt(position), PX, H-10);
    ctx.textAlign='right'; ctx.fillText(fmt(dur), PX+PW, H-10);
    ctx.textAlign='left'; ctx.shadowColor='transparent';

    return canvas.toBuffer('image/png');
}

export const data = {
    data: new SlashCommandBuilder()
        .setName('nowplaying')
        .setDescription('Show the currently playing track'),
    category: 'music',

    async execute(interaction, client) {
        const player = client.riffy.players.get(interaction.guildId);
        if (!player || (!player.playing && !player.paused) || !player.current)
            return interaction.reply({ content: `${emojis.warn} Nothing is playing right now.`, ephemeral: true });

        await interaction.deferReply();
        try {
            const track = player.current;
            const buf = await drawNP(track, player.position || 0);
            await interaction.editReply({ files: [{ attachment: buf, name: 'np.png' }] });
        } catch(err) {
            console.error(err);
            interaction.editReply(`${emojis.cross} ${err.message}`).catch(()=>{});
        }
    }
};
