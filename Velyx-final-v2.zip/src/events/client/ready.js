import { ActivityType, Events, REST, Routes } from "discord.js";
import { info } from '../../utils/logger.js';
import premiumCheck from '../../tasks/premiumCheck.js';
import manager from '../../tasks/checkGiveaway.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { pathToFileURL } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const data = {
    name: Events.ClientReady,
    once: true,
    async execute(client) {
        info(`Logged in as ${client.user.username}`);
        if (client.riffy) client.riffy.init(client.user.id);

        // ── Register slash commands ──
        try {
            const commands = [];
            const slashPath = path.join(__dirname, '../../commands/slash');
            const folders = fs.readdirSync(slashPath);
            for (const folder of folders) {
                const files = fs.readdirSync(path.join(slashPath, folder)).filter(f => f.endsWith('.js'));
                for (const file of files) {
                    const url = pathToFileURL(path.join(slashPath, folder, file)).href;
                    const cmd = await import(url);
                    if (cmd?.data?.data?.name && typeof cmd.data.execute === 'function') {
                        commands.push(cmd.data.data.toJSON());
                    }
                }
            }
            const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);
            await rest.put(Routes.applicationCommands(client.user.id), { body: commands });
            info(`✅ Registered ${commands.length} slash commands globally.`);
        } catch (err) {
            console.error('❌ Failed to register slash commands:', err.message);
        }
        // ── End register ──

        client.user.setPresence({
            activities: [{ name: `Protecting ${client.guilds.cache.size} Servers`, type: ActivityType.Custom }],
            status: "dnd",
        });

        setInterval(() => manager.checkGiveaways(client), 30 * 1000);
        premiumCheck(client);
    },
};