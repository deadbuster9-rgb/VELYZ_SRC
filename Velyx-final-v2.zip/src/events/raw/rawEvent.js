export const data = {
    name: 'raw',
    once: false,
    async execute(packet, client) {
        if (!client.riffy) return;
        if (['VOICE_STATE_UPDATE', 'VOICE_SERVER_UPDATE'].includes(packet.t)) {
            client.riffy.updateVoiceState(packet);
        }
    }
};