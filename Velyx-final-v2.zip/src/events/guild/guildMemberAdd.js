import { Events } from "discord.js";
import { handleWelcome } from '../../functions/handleWelcome.js';
import { handleAutoRole } from '../../functions/handleautorole.js';

export const data = {
    name: Events.GuildMemberAdd,
    once: false,
    /**
     * @param {import('discord.js').GuildMember} member 
     * @param {import('../../base/Velyx').Velyx} client
     */
    async execute(member, client) {
        const guild = member.guild;
        if (!guild) return;
        handleWelcome(guild, member, client);
        handleAutoRole(guild, member, client);
    }
};
