import {
    Events, EmbedBuilder, ActionRowBuilder, ButtonBuilder,
    ButtonStyle, ChannelType, PermissionFlagsBits, MessageFlags,
    StringSelectMenuBuilder
} from 'discord.js';
import emojis from '../../config/emojis.js';
import { closeTicket } from '../../commands/slash/ticket/ticket.js';

const CATEGORIES = {
    general:    { label: 'General Support',  emoji: '🆘', color: 0x5865F2 },
    bug:        { label: 'Bug Report',        emoji: '🐛', color: 0xED4245 },
    suggestion: { label: 'Suggestion',        emoji: '💡', color: 0xFEE75C },
    premium:    { label: 'Premium Support',   emoji: '💎', color: 0xF1C40F },
    appeal:     { label: 'Appeal',            emoji: '⚖️', color: 0x57F287 },
};

export const data = {
    name: Events.InteractionCreate,
    once: false,
    async execute(interaction, client) {
        const db = client.ticketDB;

        // ── TICKET CREATE (select menu) ──
        if (interaction.isStringSelectMenu() && interaction.customId === 'ticket_create') {
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });
            const category = interaction.values[0];
            const catInfo = CATEGORIES[category] || CATEGORIES.general;

            const config = await db.get(`ticket_config_${interaction.guild.id}`);
            if (!config) return interaction.editReply({ content: `${emojis.cross} Ticket system not configured.` });

            // Check if user already has an open ticket
            const existing = await db.get(`ticket_user_${interaction.guild.id}_${interaction.user.id}`);
            if (existing) {
                const ch = interaction.guild.channels.cache.get(existing);
                if (ch) return interaction.editReply({ content: `${emojis.warn} You already have an open ticket: ${ch}` });
                await db.delete(`ticket_user_${interaction.guild.id}_${interaction.user.id}`);
            }

            // Get ticket count
            const count = (config.ticketCount || 0) + 1;
            await db.set(`ticket_config_${interaction.guild.id}`, { ...config, ticketCount: count });

            const channelName = `${catInfo.emoji.replace(/\ufe0f/g, '')}-${interaction.user.username.toLowerCase().replace(/\s+/g, '-')}-${count}`;

            // Create ticket channel
            const ticketChannel = await interaction.guild.channels.create({
                name: channelName,
                type: ChannelType.GuildText,
                parent: config.categoryId,
                permissionOverwrites: [
                    { id: interaction.guild.roles.everyone, deny: [PermissionFlagsBits.ViewChannel] },
                    { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.AttachFiles] },
                    { id: config.supportRoleId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.AttachFiles] },
                    { id: config.adminRoleId, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.AttachFiles] },
                    { id: client.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.ReadMessageHistory] },
                ],
                topic: `Ticket by ${interaction.user.username} | Category: ${catInfo.label} | ID: #${count}`,
            });

            // Save ticket data
            await db.set(`ticket_channel_${ticketChannel.id}`, {
                userId: interaction.user.id,
                category,
                guildId: interaction.guild.id,
                count,
                createdAt: Date.now(),
            });
            await db.set(`ticket_user_${interaction.guild.id}_${interaction.user.id}`, ticketChannel.id);

            // Send welcome embed in ticket
            const welcomeEmbed = new EmbedBuilder()
                .setColor(catInfo.color)
                .setTitle(`${catInfo.emoji} ${catInfo.label} — Ticket #${count}`)
                .setDescription(
                    `Welcome ${interaction.user}!\n\n` +
                    `A member of our team <@&${config.supportRoleId}> will be with you shortly.\n\n` +
                    `📌 **Please describe your issue in detail.**\n` +
                    `📎 You can attach files, images, or screenshots.\n\n` +
                    `*Use the buttons below to manage this ticket.*`
                )
                .addFields(
                    { name: '👤 Opened By', value: `${interaction.user}`, inline: true },
                    { name: '📂 Category', value: catInfo.label, inline: true },
                    { name: '🎟️ Ticket ID', value: `#${count}`, inline: true },
                )
                .setThumbnail(interaction.user.displayAvatarURL({ size: 256 }))
                .setTimestamp();

            const controlRow = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('ticket_close')
                    .setLabel('Close Ticket')
                    .setStyle(ButtonStyle.Danger)
                    .setEmoji('🔒'),
                new ButtonBuilder()
                    .setCustomId('ticket_claim')
                    .setLabel('Claim Ticket')
                    .setStyle(ButtonStyle.Success)
                    .setEmoji('✋'),
                new ButtonBuilder()
                    .setCustomId('ticket_lock')
                    .setLabel('Lock')
                    .setStyle(ButtonStyle.Secondary)
                    .setEmoji('🔐'),
                new ButtonBuilder()
                    .setCustomId('ticket_transcript')
                    .setLabel('Transcript')
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji('📄'),
            );

            await ticketChannel.send({
                content: `${interaction.user} | <@&${config.supportRoleId}> | <@&${config.adminRoleId}>`,
                embeds: [welcomeEmbed],
                components: [controlRow]
            });

            // Log ticket opening
            if (config.logChannelId) {
                const logCh = interaction.guild.channels.cache.get(config.logChannelId);
                if (logCh) {
                    const logEmbed = new EmbedBuilder()
                        .setColor(0x57F287)
                        .setTitle('🎫 New Ticket Opened')
                        .addFields(
                            { name: '👤 User', value: `${interaction.user} (${interaction.user.id})`, inline: true },
                            { name: '📂 Category', value: catInfo.label, inline: true },
                            { name: '📌 Channel', value: `${ticketChannel}`, inline: true },
                            { name: '🎟️ Ticket ID', value: `#${count}`, inline: true },
                        )
                        .setTimestamp();
                    await logCh.send({ embeds: [logEmbed] }).catch(() => {});
                }
            }

            return interaction.editReply({ content: `${emojis.tick} Your ticket has been created: ${ticketChannel}` });
        }

        // ── TICKET BUTTON ACTIONS ──
        if (interaction.isButton()) {
            const { customId } = interaction;

            if (customId === 'ticket_close') {
                const ticketData = await db.get(`ticket_channel_${interaction.channel.id}`);
                if (!ticketData) return interaction.reply({ content: `${emojis.cross} This is not a ticket channel.`, flags: MessageFlags.Ephemeral });

                // Confirm close
                const confirmEmbed = new EmbedBuilder()
                    .setColor(0xED4245)
                    .setDescription('🔒 Are you sure you want to close this ticket?');

                const confirmRow = new ActionRowBuilder().addComponents(
                    new ButtonBuilder().setCustomId('ticket_close_confirm').setLabel('Yes, Close').setStyle(ButtonStyle.Danger).setEmoji('🔒'),
                    new ButtonBuilder().setCustomId('ticket_close_cancel').setLabel('Cancel').setStyle(ButtonStyle.Secondary).setEmoji('✖️'),
                );

                return interaction.reply({ embeds: [confirmEmbed], components: [confirmRow], flags: MessageFlags.Ephemeral });
            }

            if (customId === 'ticket_close_confirm') {
                await interaction.deferReply({ flags: MessageFlags.Ephemeral });
                await closeTicket(interaction.channel, interaction.user, 'Closed via button', client, db);
                return;
            }

            if (customId === 'ticket_close_cancel') {
                return interaction.reply({ content: `${emojis.tick} Close cancelled.`, flags: MessageFlags.Ephemeral });
            }

            if (customId === 'ticket_claim') {
                const ticketData = await db.get(`ticket_channel_${interaction.channel.id}`);
                if (!ticketData) return interaction.reply({ content: `${emojis.cross} Not a ticket channel.`, flags: MessageFlags.Ephemeral });

                await db.set(`ticket_channel_${interaction.channel.id}`, { ...ticketData, claimedBy: interaction.user.id });
                await interaction.channel.setName(`claimed-${interaction.channel.name.replace(/^(claimed-)?/, '')}`).catch(() => {});

                const embed = new EmbedBuilder()
                    .setColor(0x57F287)
                    .setDescription(`${emojis.tick} **${interaction.user}** has claimed this ticket.`);
                return interaction.reply({ embeds: [embed] });
            }

            if (customId === 'ticket_lock') {
                const ticketData = await db.get(`ticket_channel_${interaction.channel.id}`);
                if (!ticketData) return interaction.reply({ content: `${emojis.cross} Not a ticket channel.`, flags: MessageFlags.Ephemeral });

                const isLocked = ticketData.locked;
                await interaction.channel.permissionOverwrites.edit(ticketData.userId, {
                    SendMessages: isLocked ? true : false
                });

                await db.set(`ticket_channel_${interaction.channel.id}`, { ...ticketData, locked: !isLocked });

                const embed = new EmbedBuilder()
                    .setColor(client.color)
                    .setDescription(isLocked ? `🔓 Ticket **unlocked** by ${interaction.user}` : `🔐 Ticket **locked** by ${interaction.user}`);
                return interaction.reply({ embeds: [embed] });
            }

            if (customId === 'ticket_transcript') {
                await interaction.deferReply({ flags: MessageFlags.Ephemeral });
                const ticketData = await db.get(`ticket_channel_${interaction.channel.id}`);
                if (!ticketData) return interaction.editReply({ content: `${emojis.cross} Not a ticket channel.` });

                const config = await db.get(`ticket_config_${interaction.guild.id}`);
                const messages = await interaction.channel.messages.fetch({ limit: 100 });
                const transcript = messages.reverse().map(m =>
                    `[${new Date(m.createdTimestamp).toLocaleString()}] ${m.author.username}: ${m.content || '[embed/attachment]'}`
                ).join('\n');

                const buf = Buffer.from(transcript, 'utf-8');

                if (config?.transcriptChannelId) {
                    const transcriptCh = interaction.guild.channels.cache.get(config.transcriptChannelId);
                    if (transcriptCh) {
                        const embed = new EmbedBuilder()
                            .setColor(0x5865F2)
                            .setTitle(`📄 Transcript — #${interaction.channel.name}`)
                            .addFields({ name: '📌 Requested By', value: `${interaction.user}` })
                            .setTimestamp();
                        await transcriptCh.send({ embeds: [embed], files: [{ attachment: buf, name: `transcript-${interaction.channel.name}.txt` }] }).catch(() => {});
                    }
                }

                await interaction.editReply({
                    content: `${emojis.tick} Transcript saved!`,
                    files: [{ attachment: buf, name: `transcript-${interaction.channel.name}.txt` }]
                });
            }
        }
    }
};
