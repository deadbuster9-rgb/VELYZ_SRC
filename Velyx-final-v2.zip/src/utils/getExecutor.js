import { PermissionFlagsBits } from 'discord.js';

/**
 * @param {import('discord.js').Guild} guild 
 * @param {AuditLogEvent} type 
 * @param {string} [targetId] 
 * @returns {Promise<import('discord.js').User | null>}
 */
async function getAuditExecutor(guild, type, targetId) {
    try {
        if(!guild || !type) return null;
        if(guild.members.me && !guild.members.me.permissions.has(PermissionFlagsBits.ViewAuditLog)) return null;
        const fetchedLogs = await guild.fetchAuditLogs({
            type,
            limit: 5,
        })

        const entry = fetchedLogs.entries.find(log =>
            targetId ? log.target?.id === targetId : true
        );

        if (!entry) return null;

        const { executor, createdTimestamp } = entry; 
        const now = Date.now();

        if (now - createdTimestamp < 5000) {
            return executor;
        }

        return null;
    } catch (err) {
        return null;
    }
}

export { getAuditExecutor }