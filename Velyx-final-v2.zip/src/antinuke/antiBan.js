import { AuditLogEvent, EmbedBuilder } from 'discord.js';
import { isBotOwner } from '../utils/isBotOwner.js';
import emojis from '../config/emojis.js';
import { sleep } from '../utils/soja.js';
import { getAuditExecutor } from '../utils/getExecutor.js';

export const data = {
    /**
     * @param {import('../base/Velyx').Velyx} client 
     */
    async execute(client) {
        // Discord.js v14: guildBanAdd emits a GuildBan object (not guild, user separately)
        client.on('guildBanAdd', async (ban) => {
            const guild = ban.guild;
            const user  = ban.user;
            if (!guild) return;

            const event = 'antiBan';

            const antinukeData = await client.antinukeDB.get(`antinukeData_${guild.id}`);
            const isAntinukeEnabled = antinukeData?.enabled || false;
            if (!isAntinukeEnabled) return;

            const extraOwners = antinukeData?.extraOwners || [];
            const whitelisted = antinukeData?.whitelisted || {};
            const punishment  = antinukeData?.punishment || 'ban';

            await sleep(200);

            const executor = await getAuditExecutor(guild, AuditLogEvent.MemberBanAdd, user.id);
            if (!executor) return;

            if (
                executor.id === client.user.id ||
                executor.id === guild.ownerId ||
                isBotOwner(executor.id) ||
                extraOwners.includes(executor.id) ||
                whitelisted[executor.id]?.events?.includes(event)
            ) return;

            let actionTaken = '';
            try {
                const executorMember = await guild.members.fetch(executor.id).catch(() => null);
                if (executorMember) {
                    switch (punishment) {
                        case 'kick':
                            if (executorMember.kickable) {
                                await executorMember.kick('Velyx Antinuke System | Anti Ban');
                                actionTaken = 'Kicked';
                            }
                            break;
                        case 'ban':
                        default:
                            if (executorMember.bannable) {
                                await executorMember.ban({ reason: 'Velyx Antinuke System | Anti Ban' });
                                actionTaken = 'Banned';
                            } else if (executorMember.manageable) {
                                await executorMember.roles.set([]);
                                await executorMember.timeout(1000 * 60 * 60 * 24 * 26, 'Velyx Antinuke System | Anti Ban');
                                actionTaken = 'Roles Removed (Fallback)';
                            }
                            break;
                    }
                }
            } catch (_) {}

            let unbanned = false;
            try {
                await guild.bans.remove(user.id, 'Velyx Antinuke System | Unauthorized Ban');
                unbanned = true;
            } catch (_) {}

            const logChannelId = antinukeData?.logsChannel;
            if (logChannelId) {
                const logChannel = guild.channels.cache.get(logChannelId)
                    || await guild.channels.fetch(logChannelId).catch(() => null);
                if (logChannel) {
                    const embed = new EmbedBuilder()
                        .setColor(client.color)
                        .setTitle('Anti-Ban Triggered')
                        .setDescription(
                            `${emojis.user} **Executor**: <@${executor.id}> (${executor.username})\n` +
                            `${emojis.user} **Banned User**: <@${user.id}> (${user.username})\n` +
                            `${emojis.action} **Action Taken**: ${actionTaken || 'No Action'}\n` +
                            `${emojis.tick} **Unbanned**: ${unbanned ? emojis.tick : emojis.cross}`
                        )
                        .setTimestamp();

                    await logChannel.send({ embeds: [embed] }).catch(() => null);
                }
            }
        });
    }
};
