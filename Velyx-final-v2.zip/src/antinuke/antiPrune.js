import { AuditLogEvent, EmbedBuilder } from 'discord.js';
import { isBotOwner } from '../utils/isBotOwner.js';
import { sleep } from '../utils/soja.js';
import emojis from '../config/emojis.js';

export const data = {
  /**
   * @param {import('../base/Velyx').Velyx} client
   */
  async execute(client) {
    client.on('guildAuditLogEntryCreate', async (entry, guild) => {
      if (entry.action !== AuditLogEvent.Prune) return;
      const event = 'antiPrune';

      const antinukeData = await client.antinukeDB.get(`antinukeData_${guild.id}`);
      if (!antinukeData?.enabled) return;

      const extraOwners = antinukeData.extraOwners || [];
      const whitelisted = antinukeData.whitelisted || {};
      const punishment = antinukeData.punishment || 'ban';

      const executor = entry.executor;
      if (
        !executor ||
        executor.id === client.user.id ||
        executor.id === guild.ownerId ||
        isBotOwner(executor.id) ||
        extraOwners.includes(executor.id) ||
        whitelisted[executor.id]?.events?.includes(event)
      ) return;

      await sleep(500);

      let actionTaken = '';
      try {
        const member = await guild.members.fetch(executor.id).catch(() => null);
        if (member) {
          switch (punishment) {
            case 'kick':
              if (member.kickable) {
                await member.kick('Velyx Antinuke System | Anti Prune');
                actionTaken = 'Kicked';
              }
              break;
            case 'ban':
            default:
              if (member.bannable) {
                await member.ban({ reason: 'Velyx Antinuke System | Anti Prune' });
                actionTaken = 'Banned';
              } else if (member.manageable) {
                await member.roles.set([]);
                await member.timeout(1000 * 60 * 60 * 24 * 26, 'Velyx Antinuke System | Anti Prune');
                actionTaken = 'Roles Removed (Fallback)';
              }
              break;
          }
        }
      } catch {}

      const logChannelId = antinukeData.logsChannel;
      if (logChannelId) {
        const logChannel = guild.channels.cache.get(logChannelId) || await guild.channels.fetch(logChannelId).catch(() => null);
        if (logChannel) {
          const embed = new EmbedBuilder()
            .setColor(client.color)
            .setTitle('Anti-Prune Triggered')
            .setDescription(
              `${emojis.user} **Executor**: <@${executor.id}> (${executor.username})\n` +
              `${emojis.action} **Action Taken**: ${actionTaken || 'No Action'}\n` +
              `${emojis.gear} **Estimated Users Pruned**: \`${entry.extra?.pruned ?? 'Unknown'}\``
            )
            .setTimestamp();

          await logChannel.send({ embeds: [embed] }).catch(() => null);
        }
      }
    });
  }
};
