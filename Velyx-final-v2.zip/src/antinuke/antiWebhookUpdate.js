import {
    AuditLogEvent,
    EmbedBuilder,
  } from 'discord.js';
  import { isBotOwner } from '../utils/isBotOwner.js';
  import emojis from '../config/emojis.js';
  import { sleep } from '../utils/soja.js';
  
  export const data = {
    /**
     * @param {import('../base/Velyx').Velyx} client
     */
    async execute(client) {
      client.on('webhooksUpdates', async (channel) => {
        if (!channel.guild) return;
        const guild = channel.guild;
        const event = 'antiWebhookUpdate';
  
        const antinukeData = await client.antinukeDB.get(`antinukeData_${guild.id}`);
        if (!antinukeData?.enabled) return;
  
        const extraOwners = antinukeData.extraOwners || [];
        const whitelisted = antinukeData.whitelisted || {};
        const punishment = antinukeData.punishment || 'ban';
  
        await sleep(500);
  
        const logs = await guild.fetchAuditLogs({ limit: 5 });
        const entry = logs.entries.find(e =>
          [AuditLogEvent.WebhookCreate, AuditLogEvent.WebhookDelete, AuditLogEvent.WebhookUpdate].includes(e.action) &&
          e.target &&
          'channelId' in e.target &&
          e.target.channelId === channel.id
        );
  
        if (!entry) return;
  
        const executor = entry.executor;
        const actionType = entry.action;
  
        if (
          executor.id === client.user.id ||
          executor.id === guild.ownerId ||
          isBotOwner(executor.id) ||
          extraOwners.includes(executor.id) ||
          whitelisted[executor.id]?.events?.includes(event)
        ) return;
  
        let actionTaken = '';
  
        try {
          const executorMember = await guild.members.fetch(executor.id).catch(() => null);
          if (executorMember) {
            switch (punishment) {
              case 'kick':
                if (executorMember.kickable) {
                  await executorMember.kick('Velyx Antinuke System | Anti Webhook Update');
                  actionTaken = 'Kicked';
                }
                break;
              case 'ban':
              default:
                if (executorMember.bannable) {
                  await executorMember.ban({ reason: 'Velyx Antinuke System | Anti Webhook Update' });
                  actionTaken = 'Banned';
                } else if (executorMember.manageable) {
                  await executorMember.roles.set([]);
                  await executorMember.timeout(1000 * 60 * 60 * 24 * 26, 'Velyx Antinuke System | Anti Webhook Update');
                  actionTaken = 'Roles Removed (Fallback)';
                }
                break;
            }
          }
        } catch {}
  
        const logChannelId = antinukeData.logsChannel;
        if (logChannelId) {
          const logChannel = await guild.channels.fetch(logChannelId).catch(() => null);
          if (logChannel) {
            const embed = new EmbedBuilder()
              .setColor(client.color)
              .setTitle('Anti-Webhook Update Triggered')
              .setDescription(
                `${emojis.user} **Executor**: <@${executor.id}> (${executor.username})\n` +
                `${emojis.action} **Action Type**: ${actionType.toString().replace('Webhook', '')}\n` +
                `${emojis.action} **Action Taken**: ${actionTaken || 'No Action'}`
              )
              .setTimestamp();
  
            await logChannel.send({ embeds: [embed] }).catch(() => null);
          }
        }
      });
    },
  };
  