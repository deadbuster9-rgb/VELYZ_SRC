import { AuditLogEvent, EmbedBuilder } from 'discord.js';
import { isBotOwner } from '../utils/isBotOwner.js';
import emojis from '../config/emojis.js';
import { sleep } from '../utils/soja.js';
import { getAuditExecutor } from '../utils/getExecutor.js';

export const data = {
  /**
   * @param {import('../base/Velyx').Velyx} client 
   */
  async execute(client) {
    client.on('roleDelete', async (role) => {
      if (!role.guild) return;
      const guild = role.guild;
      const event = 'antiRoleDelete';

      const antinukeData = await client.antinukeDB.get(`antinukeData_${guild.id}`);
      if (!antinukeData?.enabled) return;

      const extraOwners = antinukeData.extraOwners || [];
      const whitelisted = antinukeData.whitelisted || {};
      const punishment = antinukeData.punishment || 'ban';

      await sleep(200);

      const executor = await getAuditExecutor(guild, AuditLogEvent.RoleDelete, role.id);
      if (!executor) return;

      if (
        executor.id === client.user.id ||
        executor.id === guild.ownerId ||
        isBotOwner(executor.id) ||
        extraOwners.includes(executor.id) ||
        whitelisted[executor.id]?.events?.includes(event)
      ) return;

      let actionTaken = '';
      try {
        const executorMember = await guild.members.fetch(executor.id).catch(() => null);
        if (executorMember) {
          switch (punishment) {
            case 'kick':
              if (executorMember.kickable) {
                await executorMember.kick('Velyx Antinuke System | Anti Role Delete');
                actionTaken = 'Kicked';
              }
              break;
            case 'ban':
            default:
              if (executorMember.bannable) {
                await executorMember.ban({ reason: 'Velyx Antinuke System | Anti Role Delete' });
                actionTaken = 'Banned';
              } else if (executorMember.manageable) {
                await executorMember.roles.set([]);
                await executorMember.timeout(1000 * 60 * 60 * 24 * 26, 'Velyx Antinuke System | Anti Role Delete');
                actionTaken = 'Roles Removed (Fallback)';
              }
              break;
          }
        }
      } catch (err) {}

      let recreated = false;
      try {
        await guild.roles.create({
          name: role.name,
          color: role.color,
          hoist: role.hoist,
          permissions: role.permissions,
          mentionable: role.mentionable,
          position: role.rawPosition,
          reason: 'Velyx Antinuke System | Role Recovered',
        });
        recreated = true;
      } catch (err) {
        recreated = false;
      }

      const logChannelId = antinukeData.logsChannel;
      if (logChannelId) {
        const logChannel = guild.channels.cache.get(logChannelId) || await guild.channels.fetch(logChannelId).catch(() => null);
        if (logChannel) {
          const embed = new EmbedBuilder()
            .setColor(client.color)
            .setTitle('Anti-Role Delete Triggered')
            .setDescription(
              `${emojis.user} **Executor**: <@${executor.id}> (${executor.username})\n` +
              `${emojis.role} **Role**: \`${role.name}\` (${role.id})\n` +
              `${emojis.action} **Action Taken**: ${actionTaken || 'No Action'}\n` +
              `${emojis.gear} **Role Recreated**: ${recreated ? emojis.tick : emojis.cross}`
            )
            .setTimestamp();

          await logChannel.send({ embeds: [embed] }).catch(() => null);
        }
      }
    });
  }
};
