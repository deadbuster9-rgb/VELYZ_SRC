import { AuditLogEvent, EmbedBuilder } from 'discord.js';
import { isBotOwner } from '../utils/isBotOwner.js';
import emojis from '../config/emojis.js';
import { sleep } from '../utils/soja.js';
import { getAuditExecutor } from '../utils/getExecutor.js';

export const data = {
    /**
     * @param {import('../base/Velyx').Velyx} client 
     */
    async execute(client) {
        client.on('guildMemberRemove', async (member) => {
            const guild = member.guild;
            const event = 'antiKick';

            const antinukeData = await client.antinukeDB.get(`antinukeData_${guild.id}`);
            const isAntinukeEnabled = antinukeData?.enabled || false;
            if (!isAntinukeEnabled) return;

            const extraOwners = antinukeData?.extraOwners || [];
            const whitelisted = antinukeData?.whitelisted || {};
            const punishment = antinukeData?.punishment || 'ban';

            await sleep(200);

            const auditLogs = await guild.fetchAuditLogs({
                type: AuditLogEvent.MemberKick,
                limit: 1
            }).catch(() => null);

            const kickLog = auditLogs?.entries.first();
            if (!kickLog || kickLog.target?.id !== member.id) return;

            const executor = kickLog.executor;
            if (!executor) return;

            if (
                executor.id === client.user.id ||
                executor.id === guild.ownerId ||
                isBotOwner(executor.id) ||
                extraOwners.includes(executor.id) ||
                whitelisted[executor.id]?.events?.includes(event)
            ) return;

            let actionTaken = '';
            try {
                const executorMember = await guild.members.fetch(executor.id).catch(() => null);
                if (executorMember) {
                    switch (punishment) {
                        case 'kick':
                            if (executorMember.kickable) {
                                await executorMember.kick('Velyx Antinuke System | Anti Kick');
                                actionTaken = 'Kicked';
                            }
                            break;
                        case 'ban':
                        default:
                            if (executorMember.bannable) {
                                await executorMember.ban({ reason: 'Velyx Antinuke System | Anti Kick' });
                                actionTaken = 'Banned';
                            } else if (executorMember.manageable) {
                                await executorMember.roles.set([]);
                                await executorMember.timeout(1000 * 60 * 60 * 24 * 26, 'Velyx Antinuke System | Anti Kick');
                                actionTaken = 'Roles Removed (Fallback)';
                            }
                            break;
                    }
                }
            } catch (err) {
            }

            const logChannelId = antinukeData?.logsChannel;
            if (logChannelId) {
                const logChannel = guild.channels.cache.get(logChannelId) || await guild.channels.fetch(logChannelId).catch(() => null);
                if (logChannel) {
                    const embed = new EmbedBuilder()
                        .setColor(client.color)
                        .setTitle('Anti-Kick Triggered')
                        .setDescription(
                            `${emojis.user} **Executor**: <@${executor.id}> (${executor.username})\n` +
                            `${emojis.user} **Kicked User**: ${member.user.username} (${member.id})\n` +
                            `${emojis.action} **Action Taken**: ${actionTaken || 'No Action'}` 
                        )
                        .setTimestamp();

                    await logChannel.send({ embeds: [embed] }).catch(() => null);
                }
            }
        });
    }
};