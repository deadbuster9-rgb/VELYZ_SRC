import { AuditLogEvent, EmbedBuilder } from 'discord.js';
import { isBotOwner } from '../utils/isBotOwner.js';
import emojis from '../config/emojis.js';
import { sleep } from '../utils/soja.js';
import { getAuditExecutor } from '../utils/getExecutor.js';

export const data = {
  /**
   * @param {import('../base/Velyx').Velyx} client 
   */
  async execute(client) {
    client.on('emojiDelete', async (emoji) => {
      const guild = emoji.guild;
      if (!guild) return;
      const event = 'antiEmojiDelete';

      const antinukeData = await client.antinukeDB.get(`antinukeData_${guild.id}`);
      if (!antinukeData?.enabled) return;

      const extraOwners = antinukeData.extraOwners || [];
      const whitelisted = antinukeData.whitelisted || {};
      const punishment = antinukeData.punishment || 'ban';

      await sleep(200);

      const executor = await getAuditExecutor(guild, AuditLogEvent.EmojiDelete, emoji.id);
      if (!executor) return;

      if (
        executor.id === client.user.id ||
        executor.id === guild.ownerId ||
        isBotOwner(executor.id) ||
        extraOwners.includes(executor.id) ||
        whitelisted[executor.id]?.events?.includes(event)
      ) return;

      let actionTaken = '';
      try {
        const executorMember = await guild.members.fetch(executor.id).catch(() => null);
        if (executorMember) {
          switch (punishment) {
            case 'kick':
              if (executorMember.kickable) {
                await executorMember.kick('Velyx Antinuke System | Anti Emoji Delete');
                actionTaken = 'Kicked';
              }
              break;
            case 'ban':
            default:
              if (executorMember.bannable) {
                await executorMember.ban({ reason: 'Velyx Antinuke System | Anti Emoji Delete' });
                actionTaken = 'Banned';
              } else if (executorMember.manageable) {
                await executorMember.roles.set([]);
                await executorMember.timeout(1000 * 60 * 60 * 24 * 26, 'Velyx Antinuke System | Anti Emoji Delete');
                actionTaken = 'Roles Removed (Fallback)';
              }
              break;
          }
        }
      } catch {}

      let recreated = false;
      try {
        const emojiBuffer = await fetch(emoji.url).then(res => res.arrayBuffer());
        const file = Buffer.from(emojiBuffer);
        const newEmoji = await guild.emojis.create({
          attachment: file,
          name: emoji.name,
          reason: 'Velyx Antinuke System | Emoji Recovered'
        });
        recreated = !!newEmoji;
      } catch (err) {
        recreated = false;
      }

      const logChannelId = antinukeData.logsChannel;
      if (logChannelId) {
        const logChannel = guild.channels.cache.get(logChannelId) || await guild.channels.fetch(logChannelId).catch(() => null);
        if (logChannel) {
          const embed = new EmbedBuilder()
            .setColor(client.color)
            .setTitle('Anti-Emoji Delete Triggered')
            .setDescription(
              `${emojis.user} **Executor**: <@${executor.id}> (${executor.username})\n` +
              `${emojis.emoji} **Emoji**: \`${emoji.name}\` (${emoji.id})\n` +
              `${emojis.action} **Action Taken**: ${actionTaken || 'No Action'}\n` +
              `${emojis.gear} **Emoji Recreated**: ${recreated ? emojis.tick : emojis.cross}`
            )
            .setTimestamp();

          await logChannel.send({ embeds: [embed] }).catch(() => null);
        }
      }
    });
  }
};
