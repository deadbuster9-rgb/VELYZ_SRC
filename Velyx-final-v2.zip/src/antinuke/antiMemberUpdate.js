import {
    AuditLogEvent,
    EmbedBuilder,
  } from 'discord.js';
  import { isBotOwner } from '../utils/isBotOwner.js';
  import emojis from '../config/emojis.js';
  import { sleep } from '../utils/soja.js';
  import { getAuditExecutor } from '../utils/getExecutor.js';
  
  export const data = {
    /**
     * @param {import('../base/Velyx').Velyx} client 
     */
    async execute(client) {
      client.on('guildMemberUpdate', async (oldMember, newMember) => {
        const guild = newMember.guild;
        const event = 'antiMemberUpdate';
  
        const antinukeData = await client.antinukeDB.get(`antinukeData_${guild.id}`);
        if (!antinukeData?.enabled) return;
  
        const extraOwners = antinukeData.extraOwners || [];
        const whitelisted = antinukeData.whitelisted || {};
        const punishment = antinukeData.punishment || 'ban';
  
        const logChannelId = antinukeData.logsChannel;
  
        const roleChanged = JSON.stringify([...oldMember.roles.cache.keys()].sort()) !== JSON.stringify([...newMember.roles.cache.keys()].sort());
        const nicknameChanged = oldMember.nickname !== newMember.nickname;
        const timeoutChanged = oldMember.communicationDisabledUntilTimestamp !== newMember.communicationDisabledUntilTimestamp;
  
        if (!roleChanged && !nicknameChanged && !timeoutChanged) return;
  
        await sleep(200);
  
        const executor = await getAuditExecutor(guild, AuditLogEvent.MemberUpdate, newMember.id)
          || await getAuditExecutor(guild, AuditLogEvent.MemberRoleUpdate, newMember.id);
        if (!executor) return;
  
        if (
          executor.id === client.user.id ||
          executor.id === guild.ownerId ||
          isBotOwner(executor.id) ||
          extraOwners.includes(executor.id) ||
          whitelisted[executor.id]?.events?.includes(event)
        ) return;
  
        let actionTaken = '';
        try {
          const executorMember = await guild.members.fetch(executor.id).catch(() => null);
          if (executorMember) {
            switch (punishment) {
              case 'kick':
                if (executorMember.kickable) {
                  await executorMember.kick('Velyx Antinuke System | Anti Member Update');
                  actionTaken = 'Kicked';
                }
                break;
              case 'ban':
              default:
                if (executorMember.bannable) {
                  await executorMember.ban({ reason: 'Velyx Antinuke System | Anti Member Update' });
                  actionTaken = 'Banned';
                } else if (executorMember.manageable) {
                  await executorMember.roles.set([]);
                  await executorMember.timeout(1000 * 60 * 60 * 24 * 26, 'Velyx Antinuke System | Anti Member Update');
                  actionTaken = 'Roles Removed (Fallback)';
                }
                break;
            }
          }
        } catch (err) {}
  
        let reverted = false;
        try {
          if (roleChanged) {
            await newMember.roles.set(oldMember.roles.cache, 'Velyx Antinuke System | Reverting Role Update');
          }
  
          if (nicknameChanged) {
            await newMember.setNickname(oldMember.nickname || null, 'Velyx Antinuke System | Reverting Nickname Change');
          }
  
          if (timeoutChanged) {
            await newMember.timeout(null, 'Velyx Antinuke System | Reverting Timeout');
          }
  
          reverted = true;
        } catch (err) {}
  
        if (logChannelId) {
          const logChannel = guild.channels.cache.get(logChannelId) || await guild.channels.fetch(logChannelId).catch(() => null);
          if (logChannel) {
            const embed = new EmbedBuilder()
              .setColor(client.color)
              .setTitle('Anti-Member Update Triggered')
              .setDescription(
                `${emojis.user} **Executor**: <@${executor.id}> (${executor.username})\n` +
                `${emojis.user} **Target**: <@${newMember.id}> (${newMember.user.username})\n` +
                `${emojis.action} **Action Taken**: ${actionTaken || 'No Action'}\n` +
                `${emojis.gear} **Changes Reverted**: ${reverted ? emojis.tick : emojis.cross}\n\n` +
                `${roleChanged ? `**Roles**: Changed\n` : ''}` +
                `${nicknameChanged ? `**Nickname**: Changed\n` : ''}` +
                `${timeoutChanged ? `**Timeout**: Changed\n` : ''}`
              )
              .setTimestamp();
  
            await logChannel.send({ embeds: [embed] }).catch(() => null);
          }
        }
      });
    }
  };
  