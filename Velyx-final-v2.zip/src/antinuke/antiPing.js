import { EmbedBuilder } from 'discord.js';
import { isBotOwner } from '../utils/isBotOwner.js';
import emojis from '../config/emojis.js';
import { getAuditExecutor } from '../utils/getExecutor.js';

export const data = {
  /**
   * @param {import('../base/Velyx').Velyx} client 
   */
  async execute(client) {
    client.on('messageCreate', async (message) => {
      if (!message.guild) return;
      const guild = message.guild;
      const event = 'antiPing';

      const antinukeData = await client.antinukeDB.get(`antinukeData_${guild.id}`);
      if (!antinukeData?.enabled) return;

      const extraOwners = antinukeData?.extraOwners || [];
      const whitelisted = antinukeData?.whitelisted || {};
      const punishment = antinukeData?.punishment || 'ban';

      const executor = message.author;
      if (
        executor.id === client.user.id ||
        executor.id === guild.ownerId ||
        isBotOwner(executor.id) ||
        extraOwners.includes(executor.id) ||
        whitelisted[executor.id]?.events?.includes(event)
      ) return;

      if (message.mentions.everyone) {
        let actionTaken = '';

        try {
          const member = await guild.members.fetch(executor.id).catch(() => null);
          if (member) {
            switch (punishment) {
              case 'kick':
                if (member.kickable) {
                  await member.kick('Velyx Antinuke System | Mass Ping');
                  actionTaken = 'Kicked';
                }
                break;
              case 'ban':
              default:
                if (member.bannable) {
                  await member.ban({ reason: 'Velyx Antinuke System | Mass Ping' });
                  actionTaken = 'Banned';
                } else if (member.manageable) {
                  await member.roles.set([]);
                  await member.timeout(1000 * 60 * 60 * 24 * 26, 'Velyx Antinuke System | Mass Ping');
                  actionTaken = 'Roles Removed (Fallback)';
                }
                break;
            }
          }
        } catch {}

        const logChannelId = antinukeData.logsChannel;
        if (logChannelId) {
          const logChannel = guild.channels.cache.get(logChannelId) || await guild.channels.fetch(logChannelId).catch(() => null);
          if (logChannel) {
            const embed = new EmbedBuilder()
              .setColor(client.color)
              .setTitle('Anti-Ping Triggered')
              .setDescription(
                `${emojis.user} **Executor**: <@${executor.id}> (${executor.username})\n` +
                `${emojis.message} **Message**: [Jump](${message.url})\n` +
                `${emojis.action} **Action Taken**: ${actionTaken || 'No Action'}`
              )
              .setTimestamp();

            await logChannel.send({ embeds: [embed] }).catch(() => null);
          }
        }

        await message.delete().catch(() => null);
      }
    });
  }
};
