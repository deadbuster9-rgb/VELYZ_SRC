import {
    AuditLogEvent,
    ChannelType,
    EmbedBuilder,
} from 'discord.js';
import { isBotOwner } from '../utils/isBotOwner.js';
import emojis from '../config/emojis.js';
import { sleep } from '../utils/soja.js';
import { getAuditExecutor } from '../utils/getExecutor.js';

export const data = {
    /**
     * @param {import('../base/Velyx').Velyx} client 
     */
    async execute(client) {
        client.on('channelUpdate', async (oldChannel, newChannel) => {
            if (!newChannel.guild || newChannel.isThread()) return;
            const guild = newChannel.guild;
            const event = 'antiChannelUpdate';

            const antinukeData = await client.antinukeDB.get(`antinukeData_${guild.id}`);
            if (!antinukeData?.enabled) return;

            const extraOwners = antinukeData.extraOwners || [];
            const whitelisted = antinukeData.whitelisted || {};
            const punishment = antinukeData.punishment || 'ban';

            await sleep(300);

            const executor = await getAuditExecutor(guild, AuditLogEvent.ChannelUpdate, newChannel.id);
            if (!executor) return;

            if (
                executor.id === client.user.id ||
                executor.id === guild.ownerId ||
                isBotOwner(executor.id) ||
                extraOwners.includes(executor.id) ||
                whitelisted[executor.id]?.events?.includes(event)
            ) return;

            let actionTaken = '';
            try {
                const executorMember = await guild.members.fetch(executor.id).catch(() => null);
                if (executorMember) {
                    switch (punishment) {
                        case 'kick':
                            if (executorMember.kickable) {
                                await executorMember.kick('Velyx Antinuke System | Anti Channel Update');
                                actionTaken = 'Kicked';
                            }
                            break;
                        case 'ban':
                        default:
                            if (executorMember.bannable) {
                                await executorMember.ban({ reason: 'Velyx Antinuke System | Anti Channel Update' });
                                actionTaken = 'Banned';
                            } else if (executorMember.manageable) {
                                await executorMember.roles.set([]);
                                await executorMember.timeout(1000 * 60 * 60 * 24 * 26, 'Velyx Antinuke System | Anti Channel Update');
                                actionTaken = 'Roles Removed (Fallback)';
                            }
                            break;
                    }
                }
            } catch {}

            let reverted = false;
            try {
                const baseOptions = {
                    name: oldChannel.name,
                    parent: oldChannel.parentId || null,
                    reason: 'Velyx Antinuke System | Reverting Channel Update',
                };

                switch (oldChannel.type) {
                    case ChannelType.GuildText:
                    case ChannelType.GuildAnnouncement:
                        await newChannel.edit({
                            ...baseOptions,
                            topic: oldChannel.topic || null,
                            nsfw: oldChannel.nsfw,
                            rateLimitPerUser: oldChannel.rateLimitPerUser,
                        });
                        reverted = true;
                        break;

                    case ChannelType.GuildVoice:
                    case ChannelType.GuildStageVoice:
                        await newChannel.edit({
                            ...baseOptions,
                            bitrate: oldChannel.bitrate,
                            userLimit: oldChannel.userLimit,
                        });
                        reverted = true;
                        break;

                    case ChannelType.GuildForum:
                        await newChannel.edit({
                            ...baseOptions,
                            defaultSortOrder: oldChannel.defaultSortOrder,
                            rateLimitPerUser: oldChannel.rateLimitPerUser,
                        });
                        reverted = true;
                        break;

                    case ChannelType.GuildCategory:
                        await newChannel.edit(baseOptions);
                        reverted = true;
                        break;

                    case ChannelType.GuildMedia:
                        await newChannel.edit({
                            ...baseOptions,
                            nsfw: oldChannel.nsfw,
                            rateLimitPerUser: oldChannel.rateLimitPerUser,
                        });
                        reverted = true;
                        break;

                    default:
                        await newChannel.edit(baseOptions);
                        reverted = true;
                        break;
                }
            } catch {}

            const logChannelId = antinukeData.logsChannel;
            if (logChannelId) {
                const logChannel = guild.channels.cache.get(logChannelId) || await guild.channels.fetch(logChannelId).catch(() => null);
                if (logChannel) {
                    const embed = new EmbedBuilder()
                        .setColor(client.color)
                        .setTitle('Anti-Channel Update Triggered')
                        .setDescription(
                            `${emojis.user} **Executor**: <@${executor.id}> (${executor.username})\n` +
                            `${emojis.action} **Action Taken**: ${actionTaken || 'No Action'}\n` +
                            `${emojis.channel} **Changes Reverted**: ${reverted ? emojis.tick : emojis.cross}`
                        )
                        .setTimestamp();

                    await logChannel.send({ embeds: [embed] }).catch(() => null);
                }
            }
        });
    }
};
