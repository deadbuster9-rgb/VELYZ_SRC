import { AuditLogEvent, EmbedBuilder } from 'discord.js';
import { isBotOwner } from '../utils/isBotOwner.js';
import emojis from '../config/emojis.js';
import { sleep } from '../utils/soja.js';
import { getAuditExecutor } from '../utils/getExecutor.js';

export const data = {
    /**
     * 
     * @param {import('../base/Velyx').Velyx} client 
     */
    async execute(client) {
        client.on('guildUpdate', async (oldGuild, newGuild) => {
            const event = 'antiGuildUpdate';
            const guild = newGuild;

            const antinukeData = await client.antinukeDB.get(`antinukeData_${guild.id}`);
            const isAntinukeEnabled = antinukeData?.enabled || false;
            if (!isAntinukeEnabled) return;

            const extraOwners = antinukeData?.extraOwners || [];
            const whitelisted = antinukeData?.whitelisted || {};
            const punishment = antinukeData?.punishment || 'ban';

            await sleep(200);

            const executor = await getAuditExecutor(guild, AuditLogEvent.GuildUpdate, guild.id);
            if (!executor) return;

            if (
                executor.id === client.user.id ||
                executor.id === guild.ownerId ||
                isBotOwner(executor.id) ||
                extraOwners.includes(executor.id) ||
                whitelisted[executor.id]?.events?.includes(event)
            ) return;

            let actionTaken = "";

            try {
                const executorMember = await guild.members.fetch(executor.id).catch(() => null);
                if (executorMember) {
                    switch (punishment) {
                        case "kick":
                            if (executorMember.kickable) {
                                await executorMember.kick("Velyx Antinuke System | Anti Guild Update");
                                actionTaken = "Kicked";
                            }
                            break;
                        case "ban":
                        default:
                            if (executorMember.bannable) {
                                await executorMember.ban({ reason: "Velyx Antinuke System | Anti Guild Update" });
                                actionTaken = "Banned";
                            } else if (executorMember.manageable) {
                                await executorMember.roles.set([]);
                                await executorMember.timeout(1000 * 60 * 60 * 24 * 26, "Velyx Antinuke System | Anti Guild Update");
                                actionTaken = "Roles Removed (Fallback)";
                            }
                            break;
                    }
                }
            } catch (err) {
            }

            let guildReverted = false;

            try {
                await newGuild.edit({
                    name: oldGuild.name,
                    description: oldGuild.description || null,
                    icon: oldGuild.iconURL({ dynamic: true }) || null,
                    banner: oldGuild.bannerURL({ dynamic: true }) || null,
                    splash: oldGuild.splashURL({ dynamic: true }) || null,
                    systemChannel: oldGuild.systemChannelId || null,
                    verificationLevel: oldGuild.verificationLevel,
                    defaultMessageNotifications: oldGuild.defaultMessageNotifications,
                    explicitContentFilter: oldGuild.explicitContentFilter,
                    afkChannel: oldGuild.afkChannelId || null,
                    afkTimeout: oldGuild.afkTimeout,
                    features: oldGuild.features || null,
                }, "Velyx Antinuke System | Guild Update Reverted");

                guildReverted = true;
            } catch (error) {
            }

            const logChannelId = antinukeData?.logsChannel;
            if (logChannelId) {
                const logChannel = guild.channels.cache.get(logChannelId) || await guild.channels.fetch(logChannelId).catch(() => null);
                if (logChannel) {
                    const embed = new EmbedBuilder()
                        .setColor(client.color)
                        .setTitle("Anti-Guild Update Triggered")
                        .setDescription(
                            `${emojis.user} **Executor**: <@${executor.id}> (${executor.username})\n` +
                            `${emojis.action} **Action Taken**: ${actionTaken || "No Action"}\n` +
                            `${emojis.server} **Guild Changes Reverted**: ${guildReverted ? emojis.tick : emojis.cross}`
                        )
                        .setTimestamp();

                    await logChannel.send({ embeds: [embed] }).catch(() => null);
                }
            }
        });
    }
};
