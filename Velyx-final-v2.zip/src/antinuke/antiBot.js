import {
    AuditLogEvent,
    EmbedBuilder,
    PermissionFlagsBits
  } from 'discord.js';
  import { isBotOwner } from '../utils/isBotOwner.js';
  import emojis from '../config/emojis.js';
  import { sleep } from '../utils/soja.js';
  import { getAuditExecutor } from '../utils/getExecutor.js';
  
  export const data = {
    /**
     * @param {import('../base/Velyx').Velyx} client 
     */
    async execute(client) {
      client.on('guildMemberAdd', async (member) => {
        if (!member.user.bot) return; 
        const guild = member.guild;
        const event = 'antiBot';
  
        const antinukeData = await client.antinukeDB.get(`antinukeData_${guild.id}`);
        if (!antinukeData?.enabled) return;
  
        const extraOwners = antinukeData.extraOwners || [];
        const whitelisted = antinukeData.whitelisted || {};
        const punishment = antinukeData.punishment || 'ban';
  
        await sleep(500); 
  
        const executor = await getAuditExecutor(guild, AuditLogEvent.BotAdd, member.id);
        if (!executor) return;
  
        if (
          executor.id === client.user.id ||
          executor.id === guild.ownerId ||
          isBotOwner(executor.id) ||
          extraOwners.includes(executor.id) ||
          whitelisted[executor.id]?.events?.includes(event)
        ) return;
  
        let actionTaken = '';
        try {
          const executorMember = await guild.members.fetch(executor.id);
          
          try {
            await member.kick('Velyx Antinuke System | Unauthorized Bot');
            actionTaken += 'Bot Removed, ';
          } catch (botRemoveErr) {
            actionTaken += 'Failed to Remove Bot, ';
          }
  
          switch (punishment) {
            case 'kick':
              if (executorMember.kickable) {
                await executorMember.kick('Velyx Antinuke System | Unauthorized Bot Addition');
                actionTaken += 'Executor Kicked';
              }
              break;
            case 'ban':
            default:
              if (executorMember.bannable) {
                await executorMember.ban({ reason: 'Velyx Antinuke System | Unauthorized Bot Addition' });
                actionTaken += 'Executor Banned';
              } else if (executorMember.manageable) {
                await executorMember.roles.set([]);
                await executorMember.timeout(1000 * 60 * 60 * 24 * 7, 'Velyx Antinuke System | Unauthorized Bot Addition');
                actionTaken += 'Executor Roles Removed + Timed Out';
              }
              break;
          }
        } catch (err) {
        }
  
        const logChannelId = antinukeData.logsChannel;
        if (logChannelId) {
          const logChannel = guild.channels.cache.get(logChannelId) || await guild.channels.fetch(logChannelId).catch(() => null);
          if (logChannel) {
            const embed = new EmbedBuilder()
              .setColor(client.color)
              .setTitle('Anti-Bot Triggered')
              .setDescription(
                `${emojis.user} **Executor**: <@${executor.id}> (${executor.username})\n` +
                `${emojis.bot} **Bot Added**: ${member.user.username} (${member.id})\n` +
                `${emojis.action} **Actions Taken**: ${actionTaken || 'No Action'}\n` +
                `${emojis.antinuke} **Protection**: ${emojis.tick} Anti-Bot System`
              )
              .setTimestamp();
  
            await logChannel.send({ embeds: [embed] }).catch(() => null);
          }
        }
      });
    }
  };