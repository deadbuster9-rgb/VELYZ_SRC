import {
    AuditLogEvent,
    EmbedBuilder,
  } from 'discord.js';
  import { isBotOwner } from '../utils/isBotOwner.js';
  import emojis from '../config/emojis.js';
  import { sleep } from '../utils/soja.js';
  import { getAuditExecutor } from '../utils/getExecutor.js';
  
  export const data = {
    /**
     * @param {import('../base/Velyx').Velyx} client 
     */
    async execute(client) {
      client.on('roleUpdate', async (oldRole, newRole) => {
        const guild = newRole.guild;
        const event = 'antiRoleUpdate';
  
        const antinukeData = await client.antinukeDB.get(`antinukeData_${guild.id}`);
        if (!antinukeData?.enabled) return;
  
        const extraOwners = antinukeData.extraOwners || [];
        const whitelisted = antinukeData.whitelisted || {};
        const punishment = antinukeData.punishment || 'ban';
  
        await sleep(200);
  
        const executor = await getAuditExecutor(guild, AuditLogEvent.RoleUpdate, newRole.id);
        if (!executor) return;
  
        if (
          executor.id === client.user.id ||
          executor.id === guild.ownerId ||
          isBotOwner(executor.id) ||
          extraOwners.includes(executor.id) ||
          whitelisted[executor.id]?.events?.includes(event)
        ) return;
  
        let actionTaken = '';
        try {
          const executorMember = await guild.members.fetch(executor.id).catch(() => null);
          if (executorMember) {
            switch (punishment) {
              case 'kick':
                if (executorMember.kickable) {
                  await executorMember.kick('Velyx Antinuke System | Anti Role Update');
                  actionTaken = 'Kicked';
                }
                break;
              case 'ban':
              default:
                if (executorMember.bannable) {
                  await executorMember.ban({ reason: 'Velyx Antinuke System | Anti Role Update' });
                  actionTaken = 'Banned';
                } else if (executorMember.manageable) {
                  await executorMember.roles.set([]);
                  await executorMember.timeout(1000 * 60 * 60 * 24 * 26, 'Velyx Antinuke System | Anti Role Update');
                  actionTaken = 'Roles Removed (Fallback)';
                }
                break;
            }
          }
        } catch (err) {}
  
        let reverted = false;
        try {
          await newRole.edit({
            name: oldRole.name,
            color: oldRole.color,
            hoist: oldRole.hoist,
            permissions: oldRole.permissions,
            mentionable: oldRole.mentionable,
            position: oldRole.position
          }, 'Velyx Antinuke System | Reverting Role Update');
          reverted = true;
        } catch (err) {}
  
        const logChannelId = antinukeData.logsChannel;
        if (logChannelId) {
          const logChannel = guild.channels.cache.get(logChannelId) || await guild.channels.fetch(logChannelId).catch(() => null);
          if (logChannel) {
            const embed = new EmbedBuilder()
              .setColor(client.color)
              .setTitle('Anti-Role Update Triggered')
              .setDescription(
                `${emojis.user} **Executor**: <@${executor.id}> (${executor.username})\n` +
                `${emojis.action} **Action Taken**: ${actionTaken || 'No Action'}\n` +
                `${emojis.role} **Changes Reverted**: ${reverted ? emojis.tick : emojis.cross}`
              )
              .setTimestamp();
  
            await logChannel.send({ embeds: [embed] }).catch(() => null);
          }
        }
      });
    }
  };
  