import { Client, GatewayIntentBits, Partials } from "discord.js";
import { QuickDB } from "quick.db";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import config from "../config/config.js";
import emojis from "../config/emojis.js";
import dotenv from "dotenv";
import { isBotOwner } from '../utils/isBotOwner.js'
import { createRequire } from 'module';          
const require = createRequire(import.meta.url);   
const { Riffy } = require('riffy');               
dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

class Velyx extends Client {
    constructor() {
        super({
            allowedMentions: {
                parse: ["roles", "users", "everyone"],
                repliedUser: false,
            },
            intents: [
                GatewayIntentBits.Guilds,
                GatewayIntentBits.GuildMembers,
                GatewayIntentBits.GuildExpressions,
                GatewayIntentBits.GuildWebhooks,
                GatewayIntentBits.GuildInvites,
                GatewayIntentBits.GuildVoiceStates,
                GatewayIntentBits.GuildPresences,
                GatewayIntentBits.GuildMessages,
                GatewayIntentBits.GuildMessageReactions,
                GatewayIntentBits.GuildMessageTyping,
                GatewayIntentBits.DirectMessages,
                GatewayIntentBits.DirectMessageReactions,
                GatewayIntentBits.DirectMessageTyping,
                GatewayIntentBits.MessageContent,
                GatewayIntentBits.GuildScheduledEvents,
                GatewayIntentBits.AutoModerationConfiguration,
                GatewayIntentBits.AutoModerationExecution,
                GatewayIntentBits.GuildModeration,
            ],
            partials: [
                Partials.GuildMember,
                Partials.User,
                Partials.Message,
                Partials.Channel,
                Partials.Reaction,
                Partials.GuildScheduledEvent,
            ],
        });


        this.config = config;
        this.cooldowns = new Map();
        this.cooldownLocks = new Map();
        this.color = config.color
        this.isBotOwner = isBotOwner
        this.setMaxListeners(0);
        // ===============================
        // 🎵 MUSIC — Riffy / Lavalink
        // ===============================
        const nodes = process.env.LAVALINK_HOST ? [
            {
                host: process.env.LAVALINK_HOST,
                password: process.env.LAVALINK_PASSWORD || 'youshallnotpass',
                port: parseInt(process.env.LAVALINK_PORT) || 2333,
                secure: process.env.LAVALINK_SECURE === 'true',
            }
        ] : [
            // Free public Lavalink nodes — multiple for redundancy
            {
                host: 'lavalink.jirayu.net',
                password: 'youshallnotpass',
                port: 13592,
                secure: false,
            },
            {
                host: 'lavalinkv3.serenetia.com',
                password: 'https://dsc.gg/aiiou',
                port: 443,
                secure: true,
            },
            {
                host: 'lavalink.oryzen.xyz',
                password: 'oryzen',
                port: 443,
                secure: true,
            },
        ];
        this.riffy = new Riffy(this, nodes, {
            send: (payload) => {
                const guild = this.guilds.cache.get(payload.d?.guild_id);
                if (guild) guild.shard.send(payload);
            },
            defaultSearchPlatform: process.env.MUSIC_SOURCE || 'scsearch',
            restVersion: 'v4',
        });

        this.riffy.on('nodeConnect', node => console.log(`[Riffy] Node "${node.name}" connected.`));
        this.riffy.on('nodeError',   (node, err) => console.error(`[Riffy] Node "${node.name}" error:`, err.message));

        this.riffy.on('trackStart', (player, track) => {
            const ch = this.channels.cache.get(player.textChannel);
            if (ch) ch.send(`${emojis.playing} Now playing: **${track.info.title}** by **${track.info.author}**`).catch(() => {});
        });

        this.riffy.on('queueEnd', (player) => {
            const ch = this.channels.cache.get(player.textChannel);
            if (ch) ch.send('✅ Queue ended. Leaving the voice channel.').catch(() => {});
            player.destroy();
        });


        this.once('shardReady', (shardId) => {
            console.log(`Shard ${shardId} is ready!`);
        })

        this.on('shardDisconnect', (event, shardId) => {
            console.log(`Shard ${shardId} disconnected. Event: ${event}`);
        })

        this.on('shardReconnecting', (shardId) => {
            console.log(`Shard ${shardId} is reconnecting...`);
        })

        this.on('shardError', (error, shardId) => {
            console.error(`Shard ${shardId} encountered an error: ${error}`);
        })

        this.on('shardResume', (id, replayedEvents) => {
            console.log(`Shard ${id} resumed. Replayed events: ${replayedEvents}`);
        })

        const databasePath = path.join(__dirname, "../../database");
        if (!fs.existsSync(databasePath)) {
            fs.mkdirSync(databasePath, { recursive: true });
        }

        this.noprefixDB = new QuickDB({ filePath: path.join(databasePath, "noprefix.db") });
        this.prefixDB = new QuickDB({ filePath: path.join(databasePath, "prefix.db") });
        this.tosDB = new QuickDB({ filePath: path.join(databasePath, "tos.db") });
        this.errorDB = new QuickDB({ filePath: path.join(databasePath, "error.db") })
        this.antinukeDB = new QuickDB({ filePath: path.join(databasePath, "antinuke.db") })
        this.badgeDB = new QuickDB({ filePath: path.join(databasePath, 'badge.db') })
        this.premiumDB = new QuickDB({ filePath: path.join(databasePath, 'premium.db') })
        this.premiumGuildDB = new QuickDB({ filePath: path.join(databasePath, 'premiumGuild.db') })
        this.userDB = new QuickDB({ filePath: path.join(databasePath, 'user.db') })
        this.automodDB = new QuickDB({ filePath: path.join(databasePath, 'automod.db') })
        this.ticketDB = new QuickDB({ filePath: path.join(databasePath, 'ticket.db') })
        this.autoreactDB = new QuickDB({ filePath: path.join(databasePath, 'autoreact.db') })
        this.loggingDB = new QuickDB({ filePath: path.join(databasePath, 'logging.db') })
        this.welcomeDB = new QuickDB({ filePath: path.join(databasePath, 'welcome.db') })
        this.j2cDB = new QuickDB({ filePath: path.join(databasePath, 'j2c.db') })
        this.activeVcDB = new QuickDB({ filePath: path.join(databasePath, 'activevc.db') })
        this.giveawayDB = new QuickDB({ filePath: path.join(databasePath, 'giveaway.db') })
        this.ignoreDB = new QuickDB({ filePath: path.join(databasePath, 'ignore.db') })
        this.afkDB = new QuickDB({ filePath: path.join(databasePath, 'afk.db') })
        this.mediaDB = new QuickDB({ filePath: path.join(databasePath, 'media.db') })
        this.autoroleDB = new QuickDB({ filePath: path.join(databasePath, 'autorole.db') })
        this.autoresponderDB = new QuickDB({ filePath: path.join(databasePath, 'autoresponder.db') })
        this.activityroleDB = new QuickDB({ filePath: path.join(databasePath, 'activityrole.db') })
    }

    async start() {
        await this.loadHandlers();
        if (!config.token) {
            console.error("Missing TOKEN");
            process.exit(1);
        }
        await this.login(config.token);
    }

    async loadHandlers() {
        const commandHandler = (await import("../handlers/commandHandler.js")).default;
        const eventHandler = (await import("../handlers/eventHandler.js")).default;
        const anticrash = (await import('../handlers/anticrash.js')).default;
        const antinuke = (await import('../handlers/antinuke.js')).default;
        const logging = (await import('../handlers/logging.js')).default;

        commandHandler(this).catch((err) => console.error(`An error occurred while loading command handler: ` + err));
        eventHandler(this).catch((err) => console.error(`An error occurred while loading event handler: ` + err));
        await anticrash(this).catch((err) => console.error(`An error occurred while loading anticrash handler: ` + err));
        await antinuke(this).catch((err) => console.error(`An error occurred while loading antinuke handler: ` + err));
        await logging(this).catch((err) => console.error(`An error occured while loading logging handler: ` + err));

    }
}

export { Velyx };
