export async function handleAutoReact(message, client) {
    if (!message.guild || message.author.bot) return;

    try {
        const allKeys = await client.autoreactDB.all();
        if (!allKeys?.length) return;

        const autoReacts = allKeys
            .filter(entry => entry.id.startsWith(`autoreact_${message.guild.id}_`))
            .map(entry => ({
                trigger: entry.id.replace(`autoreact_${message.guild.id}_`, ''),
                emoji: entry.value?.trim()
            }));

        if (!autoReacts.length) return;

        const content = message.content.toLowerCase();

        for (const { trigger, emoji } of autoReacts) {
            if (!trigger || !emoji) continue;
            if (!content.includes(trigger.toLowerCase())) continue;

            try {
                // Try direct react (works for unicode + custom emojis bot has access to)
                await message.react(emoji);
            } catch {
                try {
                    // Fallback: resolve custom emoji by ID
                    const emojiId = emoji.replace(/\D/g, '');
                    if (emojiId) {
                        const resolved = client.emojis.cache.get(emojiId);
                        if (resolved) await message.react(resolved);
                    }
                } catch (e) {
                    // Silent fail — invalid emoji
                }
            }
        }
    } catch (err) {
        console.error('AutoReact error:', err.message);
    }
}
